$('.owl-carousel').owlCarousel({
  loop:true,
  nav:true,
  items: 1,
  dots: false,
  navText : ["<i class='fas fa-chevron-left'></i>","<i class='fas fa-chevron-right'></i>"],
  autoplay: true,
  autoplayTimeout: 3000,
  smartSpeed: 1500
});