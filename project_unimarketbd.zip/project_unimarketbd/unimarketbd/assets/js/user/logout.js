function logout(event) {
  event.preventDefault();

  $.ajax({
    url: './api/user/logout.php',
    method: 'POST',
    success: function(res) {
      window.location.href = res.redirectURL;
    },
    error: function(err) {
      alert('Server Error!');
    }
  });
}