<?php
  class Orders {
    // DB stuff
    private $conn;
    private $tableName = 'orders';

    // Orders Properties
    public $id;
    public $userId;
    public $shippingPointId;
    public $paymentMethodId;
    public $userLocation;
    public $phoneNum;

    public $p;
    public $rowsPerPage;

    // Constructor with DB
    public function __construct($db) {
      $this->conn = $db;
    }

    // Read all
    public function read() {
      // Create Query
      $query = "SELECT `o`.`id` FROM `$this->tableName` `o` WHERE (SELECT COUNT(*) FROM `order_statuses_history` `osh` WHERE `osh`.`orderId` = `o`.`id`) > 1;";

      // Prepare statement
      $stmt = $this->conn->prepare($query);

      // Execute query
      $stmt->execute();

      return $stmt;
    }

    // Read By Page
    public function readByPage() {
      $startRow = ($this->p - 1) * $this->rowsPerPage;
      $rowsPerPage = $this->rowsPerPage;

      // Create Query
      $query = "SELECT * FROM `$this->tableName` ORDER BY `createdAt` DESC LIMIT $startRow, $rowsPerPage;";

      // Prepare statement
      $stmt = $this->conn->prepare($query);

      // Execute query
      $stmt->execute();

      return $stmt;
    }

    // Read Basic Info of Each Order
    public function readBasicInfoOfOrder() { 
      // Create Query
      $query = "SELECT `sp`.`name` AS `shippingPointName`, `o`.`userLocation`, `o`.`phoneNum`, `u`.`username`, `u`.`email` FROM `$this->tableName` `o`, `shipping_points` `sp`, `users` `u` WHERE `o`.`id` = :id AND `o`.`userId` = `u`.`id` AND `o`.`shippingPointId` = `sp`.`id`;";

      // Prepare statement
      $stmt = $this->conn->prepare($query);

      // Bind Param
      $stmt->bindParam(':id', $this->id);

      // Execute query
      $stmt->execute();

      return $stmt;
    }

    // Read total orders of user
    public function readTotalOrdersOfUser() {
      // Create Query
      $query = "SELECT DISTINCT `o`.`id`, `o`.`shippingPointId` FROM `$this->tableName` `o`, `order_statuses_history` `osh` WHERE `o`.`userId` = :userId AND `o`.`id` = `osh`.`orderId` AND `osh`.`status` <> 'Instantiated' ORDER BY `o`.`id` DESC;";

      // Prepare statement
      $stmt = $this->conn->prepare($query);

      // Bind Param
      $stmt->bindParam(':userId', $this->userId);

      // Execute query
      $stmt->execute();

      return $stmt;
    }

    // Create
    public function create() {
      // Create Query
      $query = "INSERT INTO `$this->tableName`(`userId`) VALUES(:userId);";

      // Prepare statement
      $stmt = $this->conn->prepare($query);

      // Bind Param
      $stmt->bindParam(':userId', $this->userId);

      // Execute query
      if($stmt->execute()) {
        return true;
      }

      return false;
    }

    // Update
    public function update() {
      // Create Query
      $query = "UPDATE `$this->tableName` SET `shippingPointId` = :shippingPointId, `paymentMethodId` = :paymentMethodId, `userLocation` = :userLocation, `phoneNum` = :phoneNum WHERE `id` = :id;";

      // Prepare statement
      $stmt = $this->conn->prepare($query);

      // Bind Param
      $stmt->bindParam(':shippingPointId', $this->shippingPointId);
      $stmt->bindParam(':paymentMethodId', $this->paymentMethodId);
      $stmt->bindParam(':userLocation', $this->userLocation);
      $stmt->bindParam(':phoneNum', $this->phoneNum);
      $stmt->bindParam(':id', $this->id);

      // Execute query
      if($stmt->execute()) {
        return true;
      }

      return false;
    }
  }
?>