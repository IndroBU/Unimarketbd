<?php
  class CustomErrors {
    public $fieldName;
    public $fieldValue;
    public $minLength;
    public $maxLength;
    public $equalValue;
    public $equalValueFieldName;
    public $matchRegex;
    public $matchRegexContains;
    public $customErrText;
    public $curErrs;

    public function __construct($fieldName, $fieldValue, $minLength, $maxLength, $equalValue, $equalValueFieldName, $matchRegex, $matchRegexContains, $customErrText, $curErrs) {
      $this->fieldName = $fieldName;
      $this->fieldValue = $fieldValue;
      $this->minLength = $minLength;
      $this->maxLength = $maxLength;
      $this->equalValue = $equalValue;
      $this->equalValueFieldName = $equalValueFieldName;
      $this->matchRegex = $matchRegex;
      $this->matchRegexContains = $matchRegexContains;
      $this->customErrText = $customErrText;
      $this->curErrs = $curErrs;
    }

    public function concatErrs() {
      if(!is_null($this->minLength) && strlen($this->fieldValue) < $this->minLength) {
        $this->curErrs[] = $this->fieldName.' should have at least '.$this->minLength.' characters';
      } else if(!is_null($this->maxLength) && strlen($this->fieldValue) > $this->maxLength) {
        $this->curErrs[] = $this->fieldName.' should have at most '.$this->maxLength.' characters';
      } else if(!is_null($this->equalValue) && ($this->fieldValue != $this->equalValue)) {
        $this->curErrs[] = $this->fieldName.' and '.$this->equalValueFieldName.' don\'t match';
      } else if(!is_null($this->matchRegexContains) && !is_null($this->matchRegex) && !preg_match($this->matchRegex, $this->fieldValue)) {
        $this->curErrs[] = $this->fieldName.' should contain '.$this->matchRegexContains;
      } else if(!is_null($this->customErrText) && !is_null($this->matchRegex) && !preg_match($this->matchRegex, $this->fieldValue)) {
        $this->curErrs[] = $this->fieldName.' '.$this->customErrText;
      }

      return $this->curErrs;
    }
  }
?>