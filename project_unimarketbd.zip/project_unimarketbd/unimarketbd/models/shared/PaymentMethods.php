<?php
  class PaymentMethods {
    // DB stuff
    private $conn;
    private $tableName = 'payment_methods';

    // Users Properties
    public $id;
    public $name;
    public $pic;

    // Constructor with DB
    public function __construct($db) {
      $this->conn = $db;
    }

    // Read All
    public function read() {
      // Create Query
      $query = "SELECT * FROM `$this->tableName`;";

      // Prepare statement
      $stmt = $this->conn->prepare($query);

      // Execute query
      $stmt->execute();

      return $stmt;
    }
  }
?>