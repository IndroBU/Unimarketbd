<?php
  // essential headers
  header('Access-Control-Allow-Origin: *');
  header('Content-Type: application/json; charset=UTF-8');
  header('Access-Control-Allow-Methods: POST');
  header('Access-Control-Max-Age: 3600');
  header('Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With');

  // essential files
  include_once '../../models/shared/CustomErrors.php';
  include_once '../../config/Constants.php';
  include_once '../../config/TimeZone.php';
  include_once '../../config/Database.php';
  include_once '../../models/user/Users.php';

  // get raw pasted data
  $data = json_decode(file_get_contents("php://input"));

  session_start();

  // exit if all fields are not passed
  if(!isset($data->passwordNew) || !isset($data->passwordConfirm) || !isset($_SESSION['userForgotPasswordDetails']['recoveryCodeMatched'])) {
    http_response_code(400);
    echo json_encode(['message' => 'Something Went Wrong']);
    exit();
  }

  $data->passwordNew = trim($data->passwordNew);
  $data->passwordConfirm = trim($data->passwordConfirm);

  $curErrs = [];

  // error handling
  $customErrors = new CustomErrors('New Password', $data->passwordNew, 8, 20, null, null, "/^[a-zA-Z0-9_-]{8,20}$/", 'alphabets, digits, hyphens and dashes', null, $curErrs);
  $curErrs = $customErrors->concatErrs();

  $customErrors = new CustomErrors('Confirm Password', $data->passwordConfirm, 8, 20, $data->passwordNew, 'New Password', "/^[a-zA-Z0-9_-]{8,20}$/", 'alphabets, digits, hyphens and dashes', null, $curErrs);
  $curErrs = $customErrors->concatErrs();

  // exit if errors found
  if(count($curErrs)) {
    http_response_code(400);
    echo json_encode(['message' => $curErrs[0]]);
    exit();
  }

  // instantiate db & connect
  $database = new Database();
  $db = $database->connect();

  // instantiate Users object
  $users = new Users($db);

  // set properties
  $users->email = $_SESSION['userForgotPasswordDetails']['email'];
  $users->password = password_hash($data->passwordNew, PASSWORD_DEFAULT);

  if(!$users->updatePasswordByEmail()) {
    http_response_code(503);
    echo json_encode(['message' => 'Reset Password Failed']);
    exit();
  }

  unset($_SESSION['userForgotPasswordDetails']);

  http_response_code(200);
  echo json_encode(['redirectURL' => SITE_URL.'/login.php']);
?>