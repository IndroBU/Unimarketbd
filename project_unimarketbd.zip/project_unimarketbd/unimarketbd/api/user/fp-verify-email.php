<?php
  // essential headers
  header('Access-Control-Allow-Origin: *');
  header('Content-Type: application/json; charset=UTF-8');
  header('Access-Control-Allow-Methods: POST');
  header('Access-Control-Max-Age: 3600');
  header('Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With');

  // essential files
  include_once '../../models/shared/CustomErrors.php';
  include_once '../../config/TimeZone.php';
  include_once '../../config/Database.php';
  include_once '../../models/user/Users.php';
  include_once '../../models/shared/SendMail.php';

  // get raw pasted data
  $data = json_decode(file_get_contents("php://input"));

  session_start();

  // exit if all fields are not passed
  if(!isset($data->email)) {
    http_response_code(400);
    echo json_encode(['message' => 'Something Went Wrong']);
    exit();
  }

  // trimming the fields
  $data->email = trim($data->email);

  // instantiate db & connect
  $database = new Database();
  $db = $database->connect();

  // instantiate Users object
  $users = new Users($db);

  // set properties
  $users->email = $data->email;

  // get user by email
  $stmt = $users->readByEmail();

  if(!$stmt->rowCount()) {
    http_response_code(404);
    echo json_encode(['message' => 'Invalid Email']);
    exit();
  }

  unset($_SESSION['userForgotPasswordDetails']);

  $_SESSION['userForgotPasswordDetails']['email'] = $data->email;
  $_SESSION['userForgotPasswordDetails']['recoveryCode'] = rand(100000, 999999);
  $_SESSION['userForgotPasswordDetails']['recoveryCodeSent'] = time();

  // send mail
  $isMailSent = SendMail($data->email, 'Recovery Code for Password Reset', 'Hello! To reset your password, the recovery code is <b>'.$_SESSION['userForgotPasswordDetails']['recoveryCode'].'</b>. Remember, this recovery code will expire in 15 minutes. Thank you.');

  if(!$isMailSent) {
    http_response_code(503);
    echo json_encode(['message' => 'Failed to send the recovery code']);
    exit();
  }

  http_response_code(200);
  echo json_encode(['message' => 'An email has been sent with recovery code']);
?>