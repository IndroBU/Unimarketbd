<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- Shared -->
  <link rel="stylesheet" href="../assets/css/shared/bootstrap.min.css">
  <link rel="stylesheet" href="../assets/css/shared/main.css">
  <!-- Admin -->
  <link rel="stylesheet" href="../assets/css/admin/sidebar.css">
  <link rel="stylesheet" href="../assets/css/admin/nav.css">
  <link rel="stylesheet" href="../assets/css/admin/categories.css">
  <title>UnimarketBd Admin | Categories</title>
</head>
<body>
  <?php
    session_start();

    include_once '../config/Constants.php';
    include_once '../config/Database.php';
    include_once '../models/admin/Admins.php';
    include_once '../models/admin/Categories.php';
    include_once '../partials/admin/sidebar.php';
    include_once '../partials/admin/nav.php';
    include_once '../partials/admin/login-with-cookie.php';
    include_once '../partials/admin/get-page-count-categories.php';
    include_once '../partials/admin/get-by-page-categories.php';
    include_once '../partials/admin/get-farthest-page-no.php';
  ?>

  <?php
    loginWithCookie();

    if(!isset($_SESSION['adminLoginDetails'])) header('location: ./login.php');
  ?>

  <?php
    if(!isset($_GET['p'])) header('location: ./categories.php?p=1');

    $curPageNo = (int) $_GET['p'];

    $maxPages = getPageCountCategories();

    if(($curPageNo != 1) && ($curPageNo < 1 || $curPageNo > $maxPages)) header('location: ./categories.php?p=1');

    $categories = getByPageCategories($curPageNo);

    $lefMostPageInPagination = getFarthestPageNo($maxPages, $curPageNo)['leftMost'];
    $rightMostPageInPagination = getFarthestPageNo($maxPages, $curPageNo)['rightMost'];
  ?>

  <?php echo sideBarHTML(); ?>
  <?php echo navHTML(); ?>

  <main class="p-4 main categories-main">
    <div class="mb-4 d-flex align-items-center justify-content-between create-category-modal-openup-container">
      <h1 class="mb-0 text-dark page-title categories-title">Categories</h1>
      <button class="btn btn-primary shadow-none create-category-modal-openup-btn" data-toggle="modal" data-target="#create-category-modal">Add a Category</button>
    </div>
    
    <!-- Table -->
    <table class="bg-white table table-bordered">
      <thead>
        <tr class="border-bottom-0">
          <th class="border-bottom-0 id">ID</th>
          <th class="border-bottom-0 name">Name</th>
          <th class="border-bottom-0 created-at">Created At</th>
          <th class="border-bottom-0 actions">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php 
          if(!$categories) {
            echo 
            "<tr>
              <td class='text-center' colspan='4'>No categories found</td>
            </tr>";
          } else {
            foreach ($categories as $category) {
              extract($category);

              $createdAt = date('F j, Y', strtotime($createdAt));

              echo 
              "<tr>
                <td class='border-bottom-0 id'>$id</td>
                <td class='border-bottom-0 name'>$name</td>
                <td class='border-bottom-0 created-at'>$createdAt</td>
                <td class='border-bottom-0 actions'>
                  <button class='btn btn-sm btn-info shadow-none'>
                    <i class='fas fa-edit'></i>
                  </button>
                  <button class='btn btn-sm btn-danger shadow-none' onclick='deleteCategoryPre(event)' data-toggle='modal' data-target='#delete-category-modal' data-category-id='$id'>
                    <i class='fas fa-trash'></i>
                  </button>
                </td>
              </tr>";
            }
          }
        ?>
      </tbody>
    </table>
    <!-- Pagination -->
    <ul class="mt-4 pagination justify-content-center">
      <?php
        if($categories) {
          if($curPageNo - 1 > 0) {
            $pageNo = $curPageNo - 1;
            echo "<li class='page-item'><a class='page-link' href='./categories.php?p=$pageNo'>Previous</a></li>";
          }
  
          for($pageNo = $lefMostPageInPagination; $pageNo <= $rightMostPageInPagination; $pageNo++) {
            $activeClass = ($pageNo == $curPageNo) ? 'active': '';
            echo "<li class='page-item $activeClass'><a class='page-link' href='./categories.php?p=$pageNo'>$pageNo</a></li>";
          }
  
          if($curPageNo + 1 <= $maxPages) {
            $pageNo = $curPageNo + 1;
            echo "<li class='page-item'><a class='page-link' href='./categories.php?p=$pageNo'>Next</a></li>";
          }
        }
      ?>
    </ul>

    <!-- Create Compnay Modal -->
    <div class="modal fade" id="create-category-modal" tabindex="-1">
      <div class="modal-dialog" role="document">
        <div class="p-4 modal-content">
          <span class="position-absolute modal-cross" data-dismiss="modal">
            <i class="fas fa-times"></i>
          </span>
          <h3 class="my-4 text-primary text-center modal-heading">Add a Category</h3>
          <form onsubmit="createCategory(event)" class="create-category-form" id="create-category-form">
            <div class="form-group">
              <label for="create-category-name">Name</label>
              <input required minlength="1" maxlength="30" type="text" class="shadow-none form-control create-category-name" id="create-category-name">
            </div>
            <button class="mt-3 btn btn-primary shadow-none create-category-btn" id="create-category-btn">Add</button>
            <div class="d-none mt-4 text-center res-msg-container">
              <!-- response goes here -->
            </div>
          </form>
        </div>
      </div>
    </div>

    <!-- Delete Compnay Modal -->
    <div class="modal fade" id="delete-category-modal" tabindex="-1">
      <div class="modal-dialog" role="document">
        <div class="p-4 modal-content">
          <span class="position-absolute modal-cross" data-dismiss="modal">
            <i class="fas fa-times"></i>
          </span>
          <h3 class="my-4 text-danger text-center modal-heading">You sure deleting this category?</h3>
          <form onsubmit="deleteCategory(event)" class="delete-category-form" id="delete-category-form" data-category-id="">
            <div class="text-center delete-category-btn-container">
              <button class="btn btn-danger shadow-none delete-category-btn" id="delete-category-btn">Delete</button>
            </div>
            <div class="d-none mt-4 text-center res-msg-container">
              <!-- response goes here -->
            </div>
          </form>
        </div>
      </div>
    </div>
  </main>

  <!-- Shared -->
  <script src="../assets/js/shared/font-awesome.min.js"></script>
  <script src="../assets/js/shared/jquery.min.js"></script>
  <script src="../assets/js/shared/bootstrap.bundle.min.js"></script>
  <script src="../assets/js/shared/main.js"></script>
  <!-- Admin -->
  <script src="../assets/js/admin/categories.js"></script>
  <script src="../assets/js/admin/logout.js"></script>
</body>
</html>