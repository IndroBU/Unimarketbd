<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- Shared -->
  <link rel="stylesheet" href="../assets/css/shared/bootstrap.min.css">
  <link rel="stylesheet" href="../assets/css/shared/main.css">
  <!-- Admin -->
  <link rel="stylesheet" href="../assets/css/admin/sidebar.css">
  <link rel="stylesheet" href="../assets/css/admin/nav.css">
  <link rel="stylesheet" href="../assets/css/admin/dashboard.css">
  <title>UnimarketBd Admin | Dashboard</title>
</head>
<body>
  <?php
    session_start();

    include_once '../config/Constants.php';
    include_once '../config/Database.php';
    include_once '../models/admin/Admins.php';
    include_once '../models/admin/Categories.php';
    include_once '../models/admin/Companies.php';
    include_once '../models/admin/Products.php';
    include_once '../models/admin/ShippingPoints.php';
    include_once '../models/user/Users.php';
    include_once '../models/user/Orders.php';
    include_once '../partials/admin/sidebar.php';
    include_once '../partials/admin/nav.php';
    include_once '../partials/admin/login-with-cookie.php';
    include_once '../partials/admin/get-dashboard-statistics.php';
  ?>

  <?php
    loginWithCookie();

    if(!isset($_SESSION['adminLoginDetails'])) header('location: ./login.php');
  ?>

  <?php echo sideBarHTML(); ?>
  <?php echo navHTML(); ?>

  <main class="p-4 main dashboard-main">
    <div class="mb-4 dashboard-header">
      <h1 class="mb-0 text-dark page-title dashboard-title">Dashboard</h1>
    </div>
    <div class="dashboard-items">
      <div class="p-3 bg-white text-dark d-flex flex-column justify-content-between dashboard-item">
        <span class="dashboard-item-title">Users</span>
        <span class="dashboard-item-count align-self-end"><?=getUsersCount()?>+</span>
      </div>
      <div class="p-3 bg-white text-dark d-flex flex-column justify-content-between dashboard-item">
        <span class="dashboard-item-title">Categories</span>
        <span class="dashboard-item-count align-self-end"><?=getCategoriesCount()?>+</span>
      </div>
      <div class="p-3 bg-white text-dark d-flex flex-column justify-content-between dashboard-item">
        <span class="dashboard-item-title">Companies</span>
        <span class="dashboard-item-count align-self-end"><?=getCompaniesCount()?>+</span>
      </div>
      <div class="p-3 bg-white text-dark d-flex flex-column justify-content-between dashboard-item">
        <span class="dashboard-item-title">Products</span>
        <span class="dashboard-item-count align-self-end"><?=getProductsCount()?>+</span>
      </div>
      <div class="p-3 bg-white text-dark d-flex flex-column justify-content-between dashboard-item">
        <span class="dashboard-item-title">Shipping Points</span>
        <span class="dashboard-item-count align-self-end"><?=getShippingPointsCount()?>+</span>
      </div>
      <div class="p-3 bg-white text-dark d-flex flex-column justify-content-between dashboard-item">
        <span class="dashboard-item-title">Orders</span>
        <span class="dashboard-item-count align-self-end"><?=getOrdersCount()?>+</span>
      </div>
    </div>
  </main>

  <!-- Shared -->
  <script src="../assets/js/shared/font-awesome.min.js"></script>
  <script src="../assets/js/shared/jquery.min.js"></script>
  <script src="../assets/js/shared/bootstrap.bundle.min.js"></script>
  <script src="../assets/js/shared/main.js"></script>
  <!-- Admin -->
  <script src="../assets/js/admin/logout.js"></script>
</body>
</html>