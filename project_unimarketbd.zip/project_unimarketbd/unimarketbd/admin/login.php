<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- Shared -->
  <link rel="stylesheet" href="../assets/css/shared/bootstrap.min.css">
  <link rel="stylesheet" href="../assets/css/shared/main.css">
  <!-- Admin -->
  <link rel="stylesheet" href="../assets/css/admin/login.css">
  <title>UnimarketBd Admin | Login</title>
</head>
<body>
  <?php
    session_start();

    include_once '../config/Constants.php';
    include_once '../config/Database.php';
    include_once '../models/admin/Admins.php';
    include_once '../partials/admin/login-with-cookie.php';
  ?>

  <?php
    loginWithCookie();

    if(isset($_SESSION['adminLoginDetails'])) header('location: ../admin');
  ?>

  <section class="login-section">
    <div class="container">
      <h1 class="mb-5 text-center text-primary login-heading">Admin Login</h1>

      <form onsubmit="login(event)" class="bg-white rounded mx-auto p-5 login-form" id="login-form">
        <div class="form-group">
          <label for="username-email">Username / E-mail</label>
          <input required type="text" class="shadow-none form-control username-email" id="username-email">
        </div>
        <div class="form-group">
          <label for="password">Password</label>
          <input required type="password" class="shadow-none form-control password" id="password">
        </div>
        <div class="d-flex justify-content-between">
          <div class="remember-me-container">
            <input type="checkbox" name="remember-me" id="remember-me">
            <label for="remember-me">Remember Me</label>
          </div>
          <!-- <a href="./forgot-password.php" class="forgot-password-text">Forgot Password?</a> -->
        </div>
        <button class="mt-3 shadow-none btn btn-primary login-btn" id="login-btn">Login</button>
        <div class="d-none mt-4 text-center res-msg-container">
          <!-- response goes here -->
        </div>
      </form>
    </div>
  </section>

  <!-- Shared -->
  <script src="../assets/js/shared/font-awesome.min.js"></script>
  <script src="../assets/js/shared/jquery.min.js"></script>
  <script src="../assets/js/shared/bootstrap.bundle.min.js"></script>
  <script src="../assets/js/shared/admin/main.js"></script>
  <!-- Admin -->
  <script src="../assets/js/admin/login.js"></script>
</body>
</html>