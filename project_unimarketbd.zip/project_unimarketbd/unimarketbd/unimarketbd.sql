-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 30, 2023 at 02:35 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `unimarketbd`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `username` varchar(12) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp(),
  `lastUpdated` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `username`, `email`, `password`, `createdAt`, `lastUpdated`) VALUES
(12, 'indro036', 'indro.cse.bu@gmail.com', '$2y$10$6ZsLE53yZrsq01VRKPgtyus8vwu7M7U/MPr6JXpWUc1XQhAFlAcr2', '2023-01-10 04:20:45', '2023-01-10 04:20:45');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `orderId` int(11) NOT NULL,
  `productId` int(11) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`orderId`, `productId`, `quantity`) VALUES
(21, 23, 2),
(21, 24, 1);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp(),
  `lastUpdated` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `createdAt`, `lastUpdated`) VALUES
(3, 'Soft Drinks', '2021-05-25 09:31:55', '2021-05-25 09:31:55'),
(4, 'Juice', '2021-05-27 08:30:56', '2021-05-27 08:30:56'),
(5, 'Fruits', '2021-05-27 08:31:04', '2021-05-27 08:31:04');

-- --------------------------------------------------------

--
-- Table structure for table `companies`
--

CREATE TABLE `companies` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `location` varchar(40) NOT NULL,
  `description` varchar(500) NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp(),
  `lastUpdated` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `companies`
--

INSERT INTO `companies` (`id`, `name`, `location`, `description`, `createdAt`, `lastUpdated`) VALUES
(15, 'Coca Cola', 'Dhaka', 'Renowned company for making soft drinks!', '2021-05-25 14:15:56', '2021-05-25 14:15:56'),
(16, 'Juice Mania', 'South Alekanda, Barishal - 8200', 'Selling premium quality juice for years!', '2021-05-27 08:32:22', '2021-05-27 08:32:22'),
(17, 'Fruit Kingdom', 'Rupatoli, Barishal - 8200', 'House of non-preservative fruits!', '2021-05-27 08:33:14', '2021-05-27 08:33:14');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `shippingPointId` int(11) DEFAULT NULL,
  `paymentMethodId` int(11) DEFAULT NULL,
  `userLocation` varchar(255) DEFAULT NULL,
  `phoneNum` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `userId`, `shippingPointId`, `paymentMethodId`, `userLocation`, `phoneNum`) VALUES
(21, 15, 1, NULL, 'Rupatoli Housing', '01312345678'),
(22, 15, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `order_contains`
--

CREATE TABLE `order_contains` (
  `orderId` int(11) NOT NULL,
  `productId` int(11) NOT NULL,
  `productName` varchar(30) NOT NULL,
  `productCategoryName` varchar(30) NOT NULL,
  `productCompanyName` varchar(30) NOT NULL,
  `productUnitPrice` decimal(10,2) NOT NULL,
  `productShippingCost` decimal(10,2) NOT NULL,
  `productQuantity` int(11) NOT NULL,
  `productDescription` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_contains`
--

INSERT INTO `order_contains` (`orderId`, `productId`, `productName`, `productCategoryName`, `productCompanyName`, `productUnitPrice`, `productShippingCost`, `productQuantity`, `productDescription`) VALUES
(21, 23, 'Test', 'Soft Drinks', 'Coca Cola', '12.00', '12.00', 2, 'Test description..'),
(21, 24, 'Test0211', 'Fruits', 'Fruit Kingdom', '212.00', '1115.00', 1, 'Bu Test...');

-- --------------------------------------------------------

--
-- Table structure for table `order_statuses_history`
--

CREATE TABLE `order_statuses_history` (
  `orderId` int(11) NOT NULL,
  `status` varchar(20) NOT NULL,
  `changedAt` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_statuses_history`
--

INSERT INTO `order_statuses_history` (`orderId`, `status`, `changedAt`) VALUES
(21, 'Instantiated', '2023-03-30 00:34:50'),
(21, 'Pending', '2023-03-30 00:35:13'),
(22, 'Instantiated', '2023-03-30 00:35:13');

-- --------------------------------------------------------

--
-- Table structure for table `payment_methods`
--

CREATE TABLE `payment_methods` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `pic` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payment_methods`
--

INSERT INTO `payment_methods` (`id`, `name`, `pic`) VALUES
(1, 'Bkash', 'assets/img/shared/payment-methods/bkash.jpg'),
(2, 'Nagad', 'assets/img/shared/payment-methods/nagad.jpg'),
(3, 'Rocket', 'assets/img/shared/payment-methods/rocket.png');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `unitPrice` decimal(10,2) NOT NULL,
  `shippingCost` decimal(10,2) NOT NULL,
  `description` varchar(500) NOT NULL,
  `hasImage` tinyint(1) DEFAULT 1,
  `categoryId` int(11) NOT NULL,
  `companyId` int(11) NOT NULL,
  `stockUnits` int(11) NOT NULL DEFAULT 100,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp(),
  `lastUpdated` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `unitPrice`, `shippingCost`, `description`, `hasImage`, `categoryId`, `companyId`, `stockUnits`, `createdAt`, `lastUpdated`) VALUES
(23, 'Test', '12.00', '12.00', 'Test description..', 1, 3, 15, 118, '2023-03-29 23:26:40', '2023-03-29 23:26:40'),
(24, 'Test0211', '212.00', '1115.00', 'Bu Test...', 1, 5, 17, 1199, '2023-03-30 00:28:48', '2023-03-30 00:28:48');

-- --------------------------------------------------------

--
-- Table structure for table `shipping_points`
--

CREATE TABLE `shipping_points` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `location` varchar(40) NOT NULL,
  `description` varchar(500) NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp(),
  `lastUpdated` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `shipping_points`
--

INSERT INTO `shipping_points` (`id`, `name`, `location`, `description`, `createdAt`, `lastUpdated`) VALUES
(1, 'Sundarban Courier Service', 'Forester Bari Lane, Barishal - 8200', 'Delivering your parcels with care for 3 decades!', '2021-05-28 12:04:08', '2021-05-28 12:04:08'),
(2, 'Akon Enterprise', 'Zero Point, Barishal - 8200', 'Serving our customers for years!', '2021-05-28 13:43:28', '2021-05-28 13:43:28');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(12) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp(),
  `lastUpdated` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `createdAt`, `lastUpdated`) VALUES
(15, 'indro036', 'indro.cse.bu@gmail.com', '$2y$10$tbNkTE9FA/HqeItL9u/a2e9Ru0dxF8dHE80d0Qd29AlD8CAr.ZYXW', '2023-01-10 04:20:12', '2023-01-10 04:20:12');

-- --------------------------------------------------------

--
-- Table structure for table `wishlist`
--

CREATE TABLE `wishlist` (
  `productId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `addedAt` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `wishlist`
--

INSERT INTO `wishlist` (`productId`, `userId`, `addedAt`) VALUES
(24, 15, '2023-03-30 00:34:15'),
(23, 15, '2023-03-30 00:34:55');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD KEY `orderId` (`orderId`),
  ADD KEY `productId` (`productId`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `companies`
--
ALTER TABLE `companies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userId` (`userId`),
  ADD KEY `shippingPointId` (`shippingPointId`),
  ADD KEY `paymentMethodId` (`paymentMethodId`);

--
-- Indexes for table `order_contains`
--
ALTER TABLE `order_contains`
  ADD KEY `orderId` (`orderId`);

--
-- Indexes for table `order_statuses_history`
--
ALTER TABLE `order_statuses_history`
  ADD KEY `orderId` (`orderId`);

--
-- Indexes for table `payment_methods`
--
ALTER TABLE `payment_methods`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `categoryId` (`categoryId`),
  ADD KEY `companyId` (`companyId`);

--
-- Indexes for table `shipping_points`
--
ALTER TABLE `shipping_points`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD KEY `productId` (`productId`),
  ADD KEY `userId` (`userId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `companies`
--
ALTER TABLE `companies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `payment_methods`
--
ALTER TABLE `payment_methods`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `shipping_points`
--
ALTER TABLE `shipping_points`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`orderId`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cart_ibfk_2` FOREIGN KEY (`productId`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`shippingPointId`) REFERENCES `shipping_points` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `orders_ibfk_3` FOREIGN KEY (`paymentMethodId`) REFERENCES `payment_methods` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `order_contains`
--
ALTER TABLE `order_contains`
  ADD CONSTRAINT `order_contains_ibfk_1` FOREIGN KEY (`orderId`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `order_statuses_history`
--
ALTER TABLE `order_statuses_history`
  ADD CONSTRAINT `order_statuses_history_ibfk_1` FOREIGN KEY (`orderId`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`categoryId`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `products_ibfk_2` FOREIGN KEY (`companyId`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD CONSTRAINT `wishlist_ibfk_1` FOREIGN KEY (`productId`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `wishlist_ibfk_2` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
