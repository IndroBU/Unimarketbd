<?php
  function getCategoriesForProducts() {
    // instantiate db & connect
    $database = new Database();
    $db = $database->connect();

    // instantiate Categories object
    $categories = new Categories($db);

    // get all categories
    $stmt = $categories->read();
    $rowCount = $stmt->rowCount();

    if(!$rowCount) return false;

    $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);

    return $categories;
  }
?>