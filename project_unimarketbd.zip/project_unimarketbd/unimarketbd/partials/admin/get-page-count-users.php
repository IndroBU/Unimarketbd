<?php
  function getPageCountUsers() {
    // instantiate db & connect
    $database = new Database();
    $db = $database->connect();

    // instantiate Users object
    $users = new Users($db);

    // get all users
    $stmt = $users->read();
    $rowCount = $stmt->rowCount();

    $totalPages = ceil($rowCount / (int) ADMIN_ROWS_PER_PAGE);

    return $totalPages;
  }
?>