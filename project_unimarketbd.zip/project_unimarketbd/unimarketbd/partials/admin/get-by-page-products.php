<?php
  function getByPageProducts($curPageNo) {
    // instantiate db & connect
    $database = new Database();
    $db = $database->connect();

    // instantiate Products object
    $products = new Products($db);

    // set properties
    $products->p = $curPageNo;
    $products->rowsPerPage = (int) ADMIN_ROWS_PER_PAGE;

    // get products by page
    $stmt = $products->readByPage();
    $rowCount = $stmt->rowCount();

    if(!$rowCount) return false;

    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);

    return $products;
  }
?>