<?php
  function navHTML() {
    $html = 
    "<nav class='border-bottom px-4 bg-white position-fixed nav'>
      <ul class='mb-0 w-100 list-unstyled d-flex align-items-center justify-content-between nav-items'>
        <li class='nav-item menu-bar-item'>
          <i class='fas fa-bars'></i>
        </li>
        <li onclick='logout()' class='nav-item logout-item'>
          <i class='fas fa-sign-out-alt'></i>
        </li>
      </ul>
    </nav>";

    return $html;
  }
?>