<?php
  function getEachOrderItems($orderId) {
    // instantiate db & connect
    $database = new Database();
    $db = $database->connect();

    // instantiate OrderContains object
    $orderContains = new OrderContains($db);

    // set properties
    $orderContains->orderId = $orderId;

    // get all order items for this particular order
    $stmt = $orderContains->readByOrderId();

    if(!$stmt->rowCount()) return false;

    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

    return $result;
  }
?>