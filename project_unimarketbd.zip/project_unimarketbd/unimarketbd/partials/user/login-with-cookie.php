<?php
  function loginWithCookie() {
    if(!isset($_COOKIE['userUsername']) || !isset($_COOKIE['userPassword'])) return;

    // instantiate db & connect
    $database = new Database();
    $db = $database->connect();

    // instantiate Users object
    $users = new Users($db);

    // set properties
    $users->username = trim($_COOKIE['userUsername']);
    $users->hashedPassword = trim($_COOKIE['userPassword']);

    // read a single user
    $stmt = $users->readByUsernameHashedPassword();

    if(!$stmt->rowCount()) return;

    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    $_SESSION['userLoginDetails']['id'] = $row['id'];
  }
?>