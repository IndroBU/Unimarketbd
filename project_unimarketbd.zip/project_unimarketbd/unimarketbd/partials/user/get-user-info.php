<?php
  function getUserInfo() {
    // instantiate db & connect
    $database = new Database();
    $db = $database->connect();

    // instantiate Users object
    $users = new Users($db);

    // set properties
    $users->id = $_SESSION['userLoginDetails']['id'];

    // get the single user
    $stmt = $users->readById();
    $rowCount = $stmt->rowCount();

    if(!$rowCount) return false;

    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    return $row;
  }
?>