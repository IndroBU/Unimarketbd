<?php
  function headerHTML() {
    $html = 
    "<header class='bg-white fixed-top header'>
      <nav class='position-relative container h-100 d-flex justify-content-between align-items-center'>
        <div class='nav-left'>
          <a href=".SITE_URL." class='text-decoration-none text-primary nav-logo'>UnimarketBd</a>
        </div>";
        
    if(isset($_SESSION['userLoginDetails'])) {
      if(getUserInfo()) {
        $html .=
        "<span class='position-absolute d-inline-block px-4 py-2 user-info'>
          Hello, @".getUserInfo()['username']."
        </span>";
      }
    }
    
    $html .=
        "<ul class='mb-0 list-unstyled d-flex align-items-center nav-right'>
          <li class='position-relative nav-item wishlist-icon' id='wishlist-icon' data-toggle='modal' data-target='#wishlistModal' data-wishlist-count='".getWishlistCount()."'>
            <span class='text-dark nav-link nav-link-fa'>
              <i class='far fa-heart'></i>
            </span>
          </li>
          <li class='position-relative nav-item cart-icon' id='cart-icon' data-toggle='modal' data-target='#cartModal' data-cart-count='".getCartCount()."'>
            <span class='text-dark nav-link nav-link-fa'>
              <i class='fas fa-shopping-cart'></i>
            </span>
          </li>
          <li class='position-relative nav-item order-icon' id='order-icon' data-toggle='modal' data-target='#ordersModal' data-orders-count='".getOrdersCount()."'>
            <span class='text-dark nav-link nav-link-fa'>
              <i class='fas fa-shopping-bag'></i>
            </span>
          </li>";
    
    isset($_SESSION['userLoginDetails']) ? 
      $html .= 
        "<li class='nav-item'>
          <a href='./' onclick='logout(event)' class='text-dark nav-link nav-link-fa'>
            <i class='fas fa-sign-out-alt'></i>
          </a>
        </li>" : 
      $html .= 
        "<li class='nav-item'>
          <a href='./login.php' class='text-dark nav-link nav-link-fa'>
            <i class='fas fa-sign-in-alt'></i>
          </a>
        </li>";   

    $html .= 
        "</ul>
      </nav>
    </header>";

    return $html;
  }
?>