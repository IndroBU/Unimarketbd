<?php
function storeCurOrderId()
{
  if (!isset($_SESSION['userLoginDetails']) || isset($_SESSION['userLoginDetails']['orderId']))
    return;

  $userId = $_SESSION['userLoginDetails']['id'];

  // instantiate db & connect
  $database = new Database();
  $db = $database->connect();

  // instantiate OrderStatusesHistory object
  $orderStatusesHistory = new OrderStatusesHistory($db);

  // set properties - order statuses history
  $orderStatusesHistory->userId = $userId;
  $orderStatusesHistory->status = 'Instantiated';

  // read last "instantiated" order
  $stmt = $orderStatusesHistory->readLast();
  $rowCount = $stmt->rowCount();

  if ($rowCount == 1) {
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    $_SESSION['userLoginDetails']['orderId'] = $row['id'];

    return;
  }

  // create a new order id otherwise

  // instantiate Orders object
  $orders = new Orders($db);

  // set properties - orders
  $orders->userId = $userId;

  $isCreated = $orders->create();

  if (!$isCreated)
    return;

  $orderId = $db->lastInsertId();

  // set properties - order statuses history
  $orderStatusesHistory->orderId = $orderId;
  $orderStatusesHistory->status = 'Instantiated';

  $isCreated = $orderStatusesHistory->create();

  if (!$isCreated)
    return;

  $_SESSION['userLoginDetails']['orderId'] = $orderId;
}
?>