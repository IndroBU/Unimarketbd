<?php
  define('SITE_URL', 'http://localhost/unimarketbd');

  define('ADMIN_ROWS_PER_PAGE', 10);
  define('ADMIN_PAGE_COUNT_IN_PAGINATION', 10);

  define('USER_PRODUCTS_PER_PAGE', 12);
  define('USER_PRODUCTS_COUNT_IN_PAGINATION', 5);

  define('PRODUCT_IMAGE_MAX_SIZE', 1000000);
  define('PRODUCT_IMAGE_FILE_TYPES', ['jpg', 'png', 'gif', 'jpeg']);
?>