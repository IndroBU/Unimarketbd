<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- Shared -->
  <link rel="stylesheet" href="./assets/css/shared/bootstrap.min.css">
  <link rel="stylesheet" href="./assets/css/shared/owl.carousel.min.css">
  <link rel="stylesheet" href="./assets/css/shared/main.css">
  <!-- User -->
  <link rel="stylesheet" href="./assets/css/user/header.css">
  <link rel="stylesheet" href="./assets/css/user/hero.css">
  <link rel="stylesheet" href="./assets/css/user/about-us.css">
  <link rel="stylesheet" href="./assets/css/user/statistics.css">
  <link rel="stylesheet" href="./assets/css/user/products.css">
  <link rel="stylesheet" href="./assets/css/user/toast-notifications.css">
  <link rel="stylesheet" href="./assets/css/user/wishlist-modal.css">
  <link rel="stylesheet" href="./assets/css/user/cart-modal.css">
  <link rel="stylesheet" href="./assets/css/user/orders-modal.css">
  <link rel="stylesheet" href="./assets/css/user/show-product-desc-modal.css">
  <title>UnimarketBd | Home</title>
</head>
<body>
  <?php
    session_start();

    include_once './config/Constants.php';
    include_once './config/Database.php';
    include_once './models/user/Users.php';
    include_once './models/admin/Categories.php';
    include_once './models/admin/Companies.php';
    include_once './models/admin/Products.php';
    include_once './models/admin/ShippingPoints.php';
    include_once './models/shared/PaymentMethods.php';
    include_once './models/user/Wishlist.php';
    include_once './models/user/Cart.php';
    include_once './models/user/Orders.php';
    include_once './models/user/OrderContains.php';
    include_once './models/user/OrderStatusesHistory.php';
    include_once './partials/user/login-with-cookie.php';
    include_once './partials/user/wishlist-modal.php';
    include_once './partials/user/toast-notifications.php';
    include_once './partials/user/cart-modal.php';
    include_once './partials/user/show-product-desc.php';
    include_once './partials/user/orders-modal.php';
    include_once './partials/user/header.php';
    include_once './partials/user/get-statistics.php';
    include_once './partials/user/get-page-count-products.php';
    include_once './partials/user/get-by-page-products.php';
    include_once './partials/user/get-farthest-page-no.php';
    include_once './partials/user/store-cur-order-id.php';
    include_once './partials/user/get-wishlist-count.php';
    include_once './partials/user/get-wishlist.php';
    include_once './partials/user/get-cart-count.php';
    include_once './partials/user/get-cart.php';
    include_once './partials/user/get-orders-count.php';
    include_once './partials/user/get-order-ids.php';
    include_once './partials/user/get-order-shipping-point.php';
    include_once './partials/user/get-order-statuses-html.php';
    include_once './partials/user/return-order-button-html.php';
    include_once './partials/user/get-order-total-cost.php';
    include_once './partials/user/get-each-order-items.php';
    include_once './partials/user/get-total-cost-of-cart.php';
    include_once './partials/user/get-shipping-points.php';
    include_once './partials/user/get-user-info.php';
    include_once './partials/shared/get-payment-methods.php';
    include_once './partials/user/footer.php';
  ?>

  <?php
    loginWithCookie();
    storeCurOrderId(); // storing current "order id" into session
  ?>

  <?php
    if(!isset($_GET['p'])) header('location: '.SITE_URL.'?p=1');

    $curPageNo = (int) $_GET['p'];
    $q = isset($_GET['q']) ? '%'. htmlspecialchars($_GET['q']) .'%' : '%%';

    $maxPages = getPageCountProducts();

    if(($curPageNo != 1) && ($curPageNo < 1 || $curPageNo > $maxPages)) header('location: '.SITE_URL.'?p=1');

    $products = getByPageProducts($curPageNo, $q);

    $lefMostPageInPagination = getFarthestPageNo($maxPages, $curPageNo)['leftMost'];
    $rightMostPageInPagination = getFarthestPageNo($maxPages, $curPageNo)['rightMost'];
  ?>

  <?php echo wishlistModal(); ?> <!-- Render wishlist modal -->
  <?php echo cartModal(); ?> <!-- Render cart modal -->
  <?php echo ordersModal(); ?> <!-- Render orders modal -->

  <?php echo headerHTML(); ?>
  <section class="hero">
    <div class="position-relative hero-carousel-items owl-carousel owl-theme">
      <div class="item hero-carousel-item hero-carousel-1">
        <div class="container">
          <h3 class="hero-sub-heading">Danish Classic</h3>
          <h1 class="my-4 hero-heading">
            Dark Stained <br/>
            Beech Stool
          </h1>
          <a class="btn btn-primary shop-now-btn">
            <span class="mr-2">Shop Now</span>
            <i class='fas fa-shopping-cart'></i>
          </a>
        </div>
      </div>
      <div class="item hero-carousel-item hero-carousel-2">
        <div class="container">
          <h3 class="hero-sub-heading">Bose Sound Sports</h3>
          <h1 class="my-4 hero-heading">
            Sports Darbuds <br/>
            Headphones Bluetooth
          </h1>
          <a class="btn btn-primary shop-now-btn">
            <span class="mr-2">Shop Now</span>
            <i class='fas fa-shopping-cart'></i>
          </a>
        </div>
      </div>
      


      <div class="item hero-carousel-item hero-carousel-3">
        <div class="container">
          <h3 class="hero-sub-heading">100% Natural</h3>
          <h1 class="my-4 hero-heading">
            Fresh Lemonade <br/>
            Summer Drinks
          </h1>
          <a class="btn btn-primary shop-now-btn">
            <span class="mr-2">Shop Now</span>
            <i class='fas fa-shopping-cart'></i>
          </a>
        </div>
      </div>
    </div>
  </section>

  <section class="py-5 about-us-section">
    <div class="container">
      <h3 class="mb-3 text-primary about-us-heading">About Us</h3>
      <p class="about-us-desc">
        The UnimarketBd is developed by Indrojit Mondal at the department of computer science and engineering at the University of Barishal and supervised by Md Samsuddoha, honorable assistant professor at the department of computer science and engineering at the University of Barishal.
      </p>
    </div>
  </section>

  <section class="py-5 bg-primary statistics-section">
    <div class="container">
      <ul class="mb-0 list-unstyled d-flex justify-content-between statistics-items">
        <li class="d-flex flex-column justify-content-center align-items-center statistics-item">
          <h4 class="mb-3 text-light statistics-title">Categories</h4>
          <span class="text-light statistics-count"><?php echo getCategoriesCount(); ?>+</span>
        </li>
        <li class="d-flex flex-column justify-content-center align-items-center statistics-item">
          <h4 class="mb-3 text-light statistics-title">Companies</h4>
          <span class="text-light statistics-count"><?php echo getCompaniesCount(); ?>+</span>
        </li>
        <li class="d-flex flex-column justify-content-center align-items-center statistics-item">
          <h4 class="mb-3 text-light statistics-title">Products</h4>
          <span class="text-light statistics-count"><?php echo getProductsCount(); ?>+</span>
        </li>
        <li class="d-flex flex-column justify-content-center align-items-center statistics-item">
          <h4 class="mb-3 text-light statistics-title">Shipping Points</h4>
          <span class="text-light statistics-count"><?php echo getShippingPointsCount(); ?>+</span>
        </li>
      </ul>
    </div>
  </section>

  <section class="py-5 products-section">
    <div class="container">
      <div class="products-heading-wrapper mb-3 d-flex justify-content-between align-items-center">
        <h3 class="mb-0 text-primary products-heading">Products</h3>
        <form action="" method="GET" class="search-products-form">
          <input type="hidden" name="p" id="q" value="<?= $_GET['p'] ?>">
          <div class="input-group">
            <input type="text" name="q" class="search-product-inp form-control shadow-none" placeholder="Search by product name, category or company..." value="<?= isset($_GET['q']) ? $_GET['q'] : '' ?>">
            <div class="input-group-append">
              <button class="btn btn-primary shadow-none" type="submit">Search</button>
            </div>
          </div>
        </form>
      </div>  
      <!-- Grid -->
      <div class="products">
        <?php
          if($products) {
            foreach ($products as $product) {
              extract($product);

              $productImgPath = glob("./assets/img/shared/products/$id.*")[0];

              echo 
              "<div class='card product' data-product-id='$id'>
                <img class='card-img-top product-img' src='$productImgPath' alt='Product Image'>
                <div class='card-body'>
                  <div class='product-basic-info'>
                    <h5 class='product-name text-primary'>$productName</h5>
                    <h6 class='product-category'>
                      From <span class='text-primary text-decoration-underline'>$categoryName</span>
                    </h6>
                    <h6 class='product-company'>
                      By <span class='text-primary text-decoration-underline'>$companyName</span>
                    </h6>
                  </div>
                  <p class='d-none product-desc'>$description</p>
                  <p class='product-stock-units'>($stockUnits units in stock)</p>
                  <div class='mt-3 d-flex align-items-center product-more-info'>
                    <span class='mr-auto text-dark product-price-cost'>
                      $unitPrice TK (+ $shippingCost TK)
                    </span>
                    <i onclick='showProductDesc(event)' data-toggle='modal' data-target='#showProductDescModal' class='add-to-wishlist-btn fas fa-eye'></i>
                    <i onclick='addToWishlist(event)' class='add-to-wishlist-btn ml-2 far fa-heart'></i>
                    <i onclick='addToCart(event)' class='add-to-cart-btn ml-2 fas fa-shopping-cart'></i>
                  </div>
                </div>
              </div>";
            }
          }
        ?>
      </div>
      <!-- Pagination -->
      <ul class="mt-4 pagination justify-content-center">
        <?php
          if($products) {
            if($curPageNo - 1 > 0) {
              $pageNo = $curPageNo - 1;
              echo "<li class='page-item'><a class='page-link' href='".SITE_URL."?p=$pageNo'>Previous</a></li>";
            }
    
            for($pageNo = $lefMostPageInPagination; $pageNo <= $rightMostPageInPagination; $pageNo++) {
              $activeClass = ($pageNo == $curPageNo) ? 'active': '';
              echo "<li class='page-item $activeClass'><a class='page-link' href='".SITE_URL."?p=$pageNo'>$pageNo</a></li>";
            }
    
            if($curPageNo + 1 <= $maxPages) {
              $pageNo = $curPageNo + 1;
              echo "<li class='page-item'><a class='page-link' href='".SITE_URL."?p=$pageNo'>Next</a></li>";
            }
          }
        ?>
      </ul>
    </div>
  </section>

  <?php echo footer(); ?> <!-- Render footer -->

  <?php echo toastNotifications(); ?> <!-- Render toast notifications -->

  <!-- Shared -->
  <script src="./assets/js/shared/font-awesome.min.js"></script>
  <script src="./assets/js/shared/jquery.min.js"></script>
  <script src="./assets/js/shared/bootstrap.bundle.min.js"></script>
  <script src="./assets/js/shared/owl.carousel.min.js"></script>
  <script src="./assets/js/shared/main.js"></script>
  <!-- User -->
  <script src="./assets/js/user/logout.js"></script>
  <script src="./assets/js/user/hero-carousel.js"></script>
  <script src="./assets/js/user/toast-notifications.js"></script>
  <script src="./assets/js/user/wishlist.js"></script>
  <script src="./assets/js/user/cart.js"></script>
  <script src="./assets/js/user/orders.js"></script>
  <script src="./assets/js/user/show-product-desc.js"></script>
</body>
</html>