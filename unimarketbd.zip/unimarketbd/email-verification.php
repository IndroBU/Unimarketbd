<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- Shared -->
  <link rel="stylesheet" href="./assets/css/shared/bootstrap.min.css">
  <link rel="stylesheet" href="./assets/css/shared/main.css">
  <!-- User -->
  <link rel="stylesheet" href="./assets/css/user/header.css">
  <link rel="stylesheet" href="./assets/css/user/email-verification.css">
  <title>UnimarketBd | Email Verification</title>
</head>
<body>
  <?php
    session_start();

    include_once './config/Constants.php';
    include_once './config/Database.php';
    include_once './models/user/Users.php';
    include_once './partials/user/login-with-cookie.php';
    include_once './partials/user/wishlist-modal.php';
    include_once './partials/user/cart-modal.php';
    include_once './partials/user/orders-modal.php';
    include_once './partials/user/header.php';
    include_once './partials/user/get-wishlist-count.php';
    include_once './partials/user/get-cart-count.php';
    include_once './partials/user/get-orders-count.php';
    include_once './partials/user/footer.php';
  ?>

  <?php
    loginWithCookie();

    if(isset($_SESSION['userLoginDetails']) || !isset($_SESSION['userRegistrationDetails'])) header('location: '.SITE_URL);
  ?>  

  <?php echo wishlistModal(); ?> <!-- Render wishlist modal -->
  <?php echo cartModal(); ?> <!-- Render cart modal -->
  <?php echo ordersModal(); ?> <!-- Render orders modal -->

  <?php echo headerHTML(); ?>
  <section class="email-verification-section">
    <div class="container">
      <h1 class="mb-5 text-center text-primary email-verification-heading">Email Verification</h1>

      <form onsubmit="emailVerification(event)" class="bg-white rounded mx-auto p-5 email-verification-form" id="email-verification-form">
        <div class="form-group">
          <label for="verification-code">Verification Code</label>
          <input minlength="6" maxlength="6" type="text" class="shadow-none form-control verification-code" id="verification-code">
          <span class="link-sent-text">* An email has been sent with verification code</span>
        </div>
        <button class="mt-3 shadow-none btn btn-primary verify-btn" id="verify-btn">Verify</button>
        <div class="d-none mt-4 text-center res-msg-container">
          <!-- response goes here -->
        </div>
      </form>
    </div>
  </section>

  <?php echo footer(); ?> <!-- Render footer -->

  <!-- Shared -->
  <script src="./assets/js/shared/font-awesome.min.js"></script>
  <script src="./assets/js/shared/jquery.min.js"></script>
  <script src="./assets/js/shared/bootstrap.bundle.min.js"></script>
  <script src="./assets/js/shared/main.js"></script>
  <!-- User -->
  <script src="./assets/js/user/email-verification.js"></script>
</body>
</html>