<?php
  // essential headers
  header('Access-Control-Allow-Origin: *');
  header('Content-Type: application/json; charset=UTF-8');
  header('Access-Control-Allow-Methods: POST');
  header('Access-Control-Max-Age: 3600');
  header('Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With');

  // essential files
  include_once '../../config/Constants.php';
  include_once '../../config/TimeZone.php';
  include_once '../../config/Database.php';
  include_once '../../models/admin/Admins.php';

  // get raw pasted data
  $data = json_decode(file_get_contents("php://input"));

  // exit if all fields are not passed
  if(!isset($data->usernameEmail) || !isset($data->password) || !isset($data->rememberMe)) {
    http_response_code(400);
    echo json_encode(['message' => 'Something Went Wrong']);
    exit();
  }

  // trimming the fields
  $data->usernameEmail = trim($data->usernameEmail);
  $data->password = trim($data->password);
  $data->rememberMe = trim($data->rememberMe);

  // instantiate db & connect
  $database = new Database();
  $db = $database->connect();

  // instantiate Admins object
  $admins = new Admins($db);

  // set properties
  $admins->usernameEmail = $data->usernameEmail;
  $admins->password = $data->password;

  // check for admin availability
  $stmt = $admins->readByUsernameEmail();
  
  if(!$stmt->rowCount()) {
    // exit if admin is not found
    http_response_code(404);
    echo json_encode(['message' => 'Invalid username/email or password']);
    exit();
  }

  // Get the row
  $row = $stmt->fetch(PDO::FETCH_ASSOC);

  // check for password match
  if(!password_verify($data->password, $row['password'])) {
    // exit if admin is not found
    http_response_code(404);
    echo json_encode(['message' => 'Invalid username/email or password']);
    exit();
  }

  // saving user id into session
  session_start();

  $_SESSION['adminLoginDetails']['id'] = $row['id'];

  // save or not save login details into cookie
  if($data->rememberMe) {
    setcookie('adminUsername', $row['username'], time() + (86400 * 30), '/');
    setcookie('adminPassword', $row['password'], time() + (86400 * 30), '/');
  } else {
    setcookie('adminUsername', '', 1, '/');
    setcookie('adminPassword', '', 1, '/');
  }

  http_response_code(200);
  echo json_encode(['redirectURL' => SITE_URL.'/admin']);
?>