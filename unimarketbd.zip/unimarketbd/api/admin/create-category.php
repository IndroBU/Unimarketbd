<?php
  // essential headers
  header('Access-Control-Allow-Origin: *');
  header('Content-Type: application/json; charset=UTF-8');
  header('Access-Control-Allow-Methods: POST');
  header('Access-Control-Max-Age: 3600');
  header('Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With');

  // essential files
  include_once '../../models/shared/CustomErrors.php';
  include_once '../../config/Constants.php';
  include_once '../../config/TimeZone.php';
  include_once '../../config/Database.php';
  include_once '../../models/admin/Categories.php';

  session_start();

  // get raw pasted data
  $data = json_decode(file_get_contents("php://input"));

  // exit if all fields are not passed
  if(!isset($data->name) || !isset($_SESSION['adminLoginDetails'])) {
    http_response_code(400);
    echo json_encode(['message' => 'Something Went Wrong']);
    exit();
  }

  // trimming the fields
  $data->name = trim($data->name);

  $curErrs = [];

  // error handling
  $customErrors = new CustomErrors('Name', $data->name, 1, 30, null, null, null, null, null, $curErrs);
  $curErrs = $customErrors->concatErrs();

  // instantiate db & connect
  $database = new Database();
  $db = $database->connect();

  // instantiate Categories object
  $categories = new Categories($db);

  // set properties
  $categories->name = $data->name;

  // creating the category
  $isCreated = $categories->create();
  
  if(!$isCreated) {
    // exit if category is not created
    http_response_code(503);
    echo json_encode(['message' => 'Failed creating the category']);
    exit();
  }

  http_response_code(201);
  echo json_encode(['redirectURL' => './categories.php?p=1']);
?>