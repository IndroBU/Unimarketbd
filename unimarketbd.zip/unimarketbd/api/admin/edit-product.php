<?php
  // essential headers
  header('Access-Control-Allow-Origin: *');
  header('Content-Type: application/json; charset=UTF-8');
  header('Access-Control-Allow-Methods: POST');
  header('Access-Control-Max-Age: 3600');
  header('Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With');

  // essential files
  include_once '../../models/shared/CustomErrors.php';
  include_once '../../models/shared/FileUpload.php';
  include_once '../../config/Constants.php';
  include_once '../../config/TimeZone.php';
  include_once '../../config/Database.php';
  include_once '../../models/admin/Categories.php';
  include_once '../../models/admin/Companies.php';
  include_once '../../models/admin/Products.php';

  session_start();

  // exit if all fields are not passed
  if(!isset($_POST['id']) || !isset($_POST['name']) || !isset($_POST['unitPrice']) || !isset($_POST['shippingCost']) || !isset($_POST['description']) || !isset($_POST['categoryId']) || !isset($_POST['companyId']) || !isset($_SESSION['adminLoginDetails'])) {
    http_response_code(400);
    echo json_encode(['message' => '_Something Went Wrong']);
    exit();
  }

  // trimming the fields
  $_POST['id'] = trim($_POST['id']);
  $_POST['name'] = trim($_POST['name']);
  $_POST['unitPrice'] = trim($_POST['unitPrice']);
  $_POST['shippingCost'] = trim($_POST['shippingCost']);
  $_POST['description'] = trim($_POST['description']);
  $_POST['categoryId'] = trim($_POST['categoryId']);
  $_POST['companyId'] = trim($_POST['companyId']);

  $curErrs = [];

  // error handling
  $customErrors = new CustomErrors('Name', $_POST['name'], 1, 30, null, null, null, null, null, $curErrs);
  $curErrs = $customErrors->concatErrs();

  if(!filter_var($_POST['unitPrice'], FILTER_VALIDATE_FLOAT)) {
    $curErrs[] = 'Invalid unit price';
  }

  if(!filter_var($_POST['shippingCost'], FILTER_VALIDATE_FLOAT)) {
    $curErrs[] = 'Invalid shipping cost';
  }

  $customErrors = new CustomErrors('Description', $_POST['description'], 1, 500, null, null, null, null, null, $curErrs);
  $curErrs = $customErrors->concatErrs();

  if(!filter_var($_POST['categoryId'], FILTER_VALIDATE_INT)) {
    $curErrs[] = 'Invalid category';
  }

  if(!filter_var($_POST['companyId'], FILTER_VALIDATE_INT)) {
    $curErrs[] = 'Invalid company';
  }

  if(!filter_var($_POST['stockUnits'], FILTER_VALIDATE_INT) || (int) $_POST['stockUnits'] < 0) {
    $curErrs[] = 'Invalid stock units';
  }

  // instantiate db & connect
  $database = new Database();
  $db = $database->connect();

  // instantiate Categories object
  $categories = new Categories($db);

  // set properties - categories
  $categories->id = $_POST['categoryId'];

  if(!$categories->readById()->rowCount()) {
    $curErrs[] = 'Invalid category';
  }

  // instantiate Companies object
  $companies = new Companies($db);

  // set properties - companies
  $companies->id = $_POST['companyId'];

  if(!$companies->readById()->rowCount()) {
    $curErrs[] = 'Invalid company';
  }

  // instantiate Products object
  $products = new Products($db);

  // set properties - products
  $products->id = $_POST['id'];
  $products->name = $_POST['name'];
  $products->unitPrice = $_POST['unitPrice'];
  $products->shippingCost = $_POST['shippingCost'];
  $products->description = $_POST['description'];
  $products->categoryId = $_POST['categoryId'];
  $products->companyId = $_POST['companyId'];
  $products->stockUnits = $_POST['stockUnits'];

  // creating the product
  $isUpdated = $products->update();
  
  if(!$isUpdated) {
    // exit if product is not created
    http_response_code(503);
    echo json_encode(['message' => 'Failed editing the product']);
    exit();
  }

  if(isset($_FILES['image'])) {
    $fileUploadErrors = FileUpload($_FILES['image'], '../../assets/img/shared/products/', $products->id, (array) PRODUCT_IMAGE_FILE_TYPES, (int) PRODUCT_IMAGE_MAX_SIZE);
  }

  http_response_code(201);
  echo json_encode(['redirectURL' => './products.php?p=1']);
?>