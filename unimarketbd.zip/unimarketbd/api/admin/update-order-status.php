<?php
  // essential headers
  header('Access-Control-Allow-Origin: *');
  header('Content-Type: application/json; charset=UTF-8');
  header('Access-Control-Allow-Methods: POST');
  header('Access-Control-Max-Age: 3600');
  header('Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With');

  // essential files
  include_once '../../config/Constants.php';
  include_once '../../config/TimeZone.php';
  include_once '../../config/Database.php';
  include_once '../../models/user/OrderStatusesHistory.php';

  session_start();

  // get raw pasted data
  $data = json_decode(file_get_contents("php://input"));

  // exit if all fields are not passed
  if(!isset($data->orderId) || !isset($data->status) || !isset($_SESSION['adminLoginDetails'])) {
    http_response_code(400);
    echo json_encode(['message' => 'Something Went Wrong']);
    exit();
  }

  // trimming the fields
  $data->orderId = trim($data->orderId);
  $data->status = trim($data->status);

  // instantiate db & connect
  $database = new Database();
  $db = $database->connect();

  // instantiate OrderStatusesHistory object
  $orderStatusesHistory = new OrderStatusesHistory($db);

  // set properties
  $orderStatusesHistory->orderId = $data->orderId;
  $orderStatusesHistory->status = $data->status;

  // creating the order status
  $isCreated = $orderStatusesHistory->create();
  
  if(!$isCreated) {
    // exit if order status is not changed
    http_response_code(503);
    echo json_encode(['message' => 'Failed changing the order status']);
    exit();
  }

  http_response_code(201);
  echo json_encode(['message' => 'Order status successfully updated']);
?>