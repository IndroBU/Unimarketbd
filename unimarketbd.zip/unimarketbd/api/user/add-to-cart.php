<?php
  // essential headers
  header('Access-Control-Allow-Origin: *');
  header('Content-Type: application/json; charset=UTF-8');
  header('Access-Control-Allow-Methods: POST');
  header('Access-Control-Max-Age: 3600');
  header('Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With');

  // essential files
  include_once '../../config/Constants.php';
  include_once '../../config/TimeZone.php';
  include_once '../../config/Database.php';
  include_once '../../models/admin/Products.php';
  include_once '../../models/user/Cart.php';

  session_start();

  // get raw pasted data
  $data = json_decode(file_get_contents("php://input"));

  // redirect to login page if not authenticated
  if(!isset($_SESSION['userLoginDetails']['id'])) {
    http_response_code(400);
    echo json_encode(['redirectURL' => SITE_URL.'/login.php']);
    exit(); 
  }

  // exit if all fields are not passed
  if(!isset($data->productId) || !isset($data->quantity) || !isset($_SESSION['userLoginDetails']['orderId'])) {
    http_response_code(400);
    echo json_encode(['message' => 'Something Went Wrong']);
    exit();
  }

  // trimming the fields
  $data->productId = trim($data->productId);
  $data->quantity = (int) $data->quantity == 0 ? 1 : (int) $data->quantity;

  // instantiate db & connect
  $database = new Database();
  $db = $database->connect();

  // instantiate Products object
  $products = new Products($db);

  // set properties
  $products->id = $data->productId;

  // fetching the product info
  $stmt = $products->readById();
  $rowCount = $stmt->rowCount();
  
  if(!$rowCount) {
    // exit if product is not found
    http_response_code(404);
    echo json_encode(['message' => 'Invalid product id']);
    exit();
  }

  // instantiate Cart object
  $cart = new Cart($db);

  // set properties
  $cart->orderId = $_SESSION['userLoginDetails']['orderId'];
  $cart->productId = $data->productId;
  $cart->quantity = $data->quantity;
  
  // read an entry with same info
  $stmt = $cart->readSingle();
  $rowCount = $stmt->rowCount();

  $operationType = '';

  // update or create
  if($rowCount) {
    // updating the quantity as it already exists into the cart
    $isUpdated = $cart->update();

    if(!$isUpdated) {
      // exit if update failed
      http_response_code(503);
      echo json_encode(['message' => 'Failed updating the quantity of the product']);
      exit();
    }

    $operationType = 'Updated';
  } else {
    // adding the product into the cart
    $isCreated = $cart->create();

    if(!$isCreated) {
      // exit if create failed
      http_response_code(503);
      echo json_encode(['message' => 'Failed adding product into the cart']);
      exit();
    }

    $operationType = 'Created';
  }

  // get the product info
  $productStmt = $products->readById();
  $productRow = $productStmt->fetch(PDO::FETCH_ASSOC);

  // calculate total cost of the order
  $cartTotalCostStmt = $cart->readTotalCost();
  $cartTotalCostRow = $cartTotalCostStmt->fetch(PDO::FETCH_ASSOC);

  // calculate total cart items of the order
  $cartTotalItemsStmt = $cart->readTotalCartItems();
  $cartTotalItemsRow = $cartTotalItemsStmt->fetch(PDO::FETCH_ASSOC);

  $productRow['imgURL'] = glob("../../assets/img/shared/products/".$productRow['id'].".*")[0];
  $productRow['quantity'] = $cart->quantity;
  $productRow['individualCost'] = number_format(($productRow['quantity'] * $productRow['unitPrice']) + $productRow['shippingCost'], 2);
  $productRow['totalCost'] = number_format($cartTotalCostRow['totalCost'], 2);
  $productRow['totalCartItems'] = $cartTotalItemsRow['totalItems'];
  $productRow['operationType'] = $operationType;
  
  http_response_code(200);
  echo json_encode(['product' => $productRow]);
?>