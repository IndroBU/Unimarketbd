<?php
  // essential headers
  header('Access-Control-Allow-Origin: *');
  header('Content-Type: application/json; charset=UTF-8');
  header('Access-Control-Allow-Methods: POST');
  header('Access-Control-Max-Age: 3600');
  header('Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With');

  // essential files
  include_once '../../models/shared/CustomErrors.php';
  include_once '../../config/TimeZone.php';
  include_once '../../config/Database.php';
  include_once '../../models/user/Users.php';

  define('VF_CODE_EXPIRED_MAX_TIME', 15 * 60);

  // get raw pasted data
  $data = json_decode(file_get_contents("php://input"));

  session_start();

  // exit if all fields are not passed
  if(!isset($data->recoveryCode) || !isset($_SESSION['userForgotPasswordDetails'])) {
    http_response_code(400);
    echo json_encode(['message' => 'Something Went Wrong']);
    exit();
  }

  // trimming the fields
  $data->recoveryCode = trim($data->recoveryCode);

  $curErrs = [];

  // error handling
  if(time() - $_SESSION['userForgotPasswordDetails']['recoveryCodeSent'] > constant('VF_CODE_EXPIRED_MAX_TIME')) {
    $curErrs[] = 'Recovery code expired';
  }

  if($data->recoveryCode != $_SESSION['userForgotPasswordDetails']['recoveryCode']) {
    $curErrs[] = 'Incorrect recovery code';
  }

  // exit if errors found
  if(count($curErrs)) {
    http_response_code(400);
    echo json_encode(['message' => $curErrs[0]]);
    exit();
  }

  $_SESSION['userForgotPasswordDetails']['recoveryCodeMatched'] = true;

  http_response_code(200);
  echo json_encode(['message' => 'Recovery code matched']);
?>