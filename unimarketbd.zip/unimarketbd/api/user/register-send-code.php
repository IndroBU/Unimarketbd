<?php
  // essential headers
  header('Access-Control-Allow-Origin: *');
  header('Content-Type: application/json; charset=UTF-8');
  header('Access-Control-Allow-Methods: POST');
  header('Access-Control-Max-Age: 3600');
  header('Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With');

  // essential files
  include_once '../../models/shared/CustomErrors.php';
  include_once '../../config/Constants.php';
  include_once '../../config/TimeZone.php';
  include_once '../../config/Database.php';
  include_once '../../models/user/Users.php';
  include_once '../../models/shared/SendMail.php';

  // get raw pasted data
  $data = json_decode(file_get_contents("php://input"));

  // exit if all fields are not passed
  if(!isset($data->username) || !isset($data->email) || !isset($data->passwordNew) || !isset($data->passwordConfirm)) {
    http_response_code(400);
    echo json_encode(['message' => 'Something Went Wrong']);
    exit();
  }

  // trimming the fields
  $data->username = trim($data->username);
  $data->email = trim($data->email);
  $data->passwordNew = trim($data->passwordNew);
  $data->passwordConfirm = trim($data->passwordConfirm);

  $curErrs = [];

  // error handling
  $customErrors = new CustomErrors('Username', $data->username, 3, 12, null, null, "/^[a-zA-Z0-9_-]{3,12}$/", 'alphabets, digits, hyphens and dashes', null, $curErrs);
  $curErrs = $customErrors->concatErrs();

  if (!filter_var($data->email, FILTER_VALIDATE_EMAIL)) {
    $curErrs[] = 'Invalid Email Address';
  }

  $customErrors = new CustomErrors('New Password', $data->passwordNew, 8, 20, null, null, "/^[a-zA-Z0-9_-]{8,20}$/", 'alphabets, digits, hyphens and dashes', null, $curErrs);
  $curErrs = $customErrors->concatErrs();

  $customErrors = new CustomErrors('Confirm Password', $data->passwordConfirm, 8, 20, $data->passwordNew, 'New Password', "/^[a-zA-Z0-9_-]{8,20}$/", 'alphabets, digits, hyphens and dashes', null, $curErrs);
  $curErrs = $customErrors->concatErrs();

  // instantiate db & connect
  $database = new Database();
  $db = $database->connect();

  // instantiate Users object
  $users = new Users($db);

  // set properties
  $users->username = $data->username;
  $users->email = $data->email;

  // check for username availability
  if($users->readByUsername()->rowCount()) {
    $curErrs[] = 'Username already used';
  }

  // check for email availability
  if($users->readByEmail()->rowCount()) {
    $curErrs[] = 'Email already used';
  }

  // exit if errors found
  if(count($curErrs)) {
    http_response_code(400);
    echo json_encode(['message' => $curErrs[0]]);
    exit();
  }

  session_start();

  unset($_SESSION['userRegistrationDetails']);

  $_SESSION['userRegistrationDetails']['username'] = $data->username;
  $_SESSION['userRegistrationDetails']['email'] = $data->email;
  $_SESSION['userRegistrationDetails']['password'] = password_hash($data->passwordNew, PASSWORD_DEFAULT);
  $_SESSION['userRegistrationDetails']['verificationCode'] = rand(100000, 999999);
  $_SESSION['userRegistrationDetails']['verificationCodeSent'] = time();

  // send mail
  $isMailSent = SendMail($data->email, 'Verification Code for Registration', 'Hello '.$data->username.'! To verify your registration, the verification code is <b>'.$_SESSION['userRegistrationDetails']['verificationCode'].'</b>. Remember, this verification code will expire in 15 minutes. Thank you.');

  if(!$isMailSent) {
    http_response_code(503);
    echo json_encode(['message' => 'Failed to send the verification code']);
    exit();
  }

  http_response_code(200);
  echo json_encode(['redirectURL' => SITE_URL.'/email-verification.php']);
?>