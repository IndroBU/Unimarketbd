<?php
  // essential headers
  header('Access-Control-Allow-Origin: *');
  header('Content-Type: application/json; charset=UTF-8');
  header('Access-Control-Allow-Methods: POST');
  header('Access-Control-Max-Age: 3600');
  header('Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With');

  // essential files
  include_once '../../config/Constants.php';
  include_once '../../config/TimeZone.php';
  include_once '../../config/Database.php';
  include_once '../../models/user/Cart.php';

  session_start();

  // get raw pasted data
  $data = json_decode(file_get_contents("php://input"));

  // exit if all fields are not passed
  if(!isset($data->productId) || !isset($_SESSION['userLoginDetails']['id']) || !isset($_SESSION['userLoginDetails']['orderId'])) {
    http_response_code(400);
    echo json_encode(['message' => 'Something Went Wrong']);
    exit();
  }

  // trimming the fields
  $data->productId = trim($data->productId);

  // instantiate db & connect
  $database = new Database();
  $db = $database->connect();

  // instantiate Cart object
  $cart = new Cart($db);

  // set properties
  $cart->productId = $data->productId;
  $cart->orderId = $_SESSION['userLoginDetails']['orderId'];
  
  // delete a cart item
  $isDeleted = $cart->delete();

  if(!$isDeleted) {
    // exit if "remove from cart" failed
    http_response_code(503);
    echo json_encode(['message' => 'Failed deleting product from cart']);
    exit();
  }

  // calculate total cost of the order
  $cartTotalCostStmt = $cart->readTotalCost();
  $cartTotalCostRow = $cartTotalCostStmt->fetch(PDO::FETCH_ASSOC);

  // calculate total cart items of the order
  $cartTotalItemsStmt = $cart->readTotalCartItems();
  $cartTotalItemsRow = $cartTotalItemsStmt->fetch(PDO::FETCH_ASSOC);

  http_response_code(200);
  echo json_encode(['message' => 'Product successfully deleted from cart', 'totalCost' => $cartTotalCostRow['totalCost'], 'totalCartItems' => $cartTotalItemsRow['totalItems']]);
?>