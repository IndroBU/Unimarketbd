<?php
  // essential headers
  header('Access-Control-Allow-Origin: *');
  header('Content-Type: application/json; charset=UTF-8');
  header('Access-Control-Allow-Methods: POST');
  header('Access-Control-Max-Age: 3600');
  header('Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With');

  // essential files
  include_once '../../models/shared/CustomErrors.php';
  include_once '../../config/Constants.php';
  include_once '../../config/TimeZone.php';
  include_once '../../config/Database.php';
  include_once '../../models/user/Users.php';

  // get raw pasted data
  $data = json_decode(file_get_contents("php://input"));

  // exit if all fields are not passed
  if(!isset($data->usernameEmail) || !isset($data->password) || !isset($data->rememberMe)) {
    http_response_code(400);
    echo json_encode(['message' => 'Something Went Wrong']);
    exit();
  }

  // trimming the fields
  $data->usernameEmail = trim($data->usernameEmail);
  $data->password = trim($data->password);
  $data->rememberMe = trim($data->rememberMe);

  // instantiate db & connect
  $database = new Database();
  $db = $database->connect();

  // instantiate Users object
  $users = new Users($db);

  // set properties
  $users->usernameEmail = $data->usernameEmail;
  $users->password = $data->password;

  // check for user availability
  $stmt = $users->readByUsernameEmail();
  
  if(!$stmt->rowCount()) {
    // exit if user is not found
    http_response_code(404);
    echo json_encode(['message' => 'Invalid username/email or password']);
    exit();
  }

  // Get the row
  $row = $stmt->fetch(PDO::FETCH_ASSOC);

  // check for password match
  if(!password_verify($data->password, $row['password'])) {
    // exit if user is not found
    http_response_code(404);
    echo json_encode(['message' => 'Invalid username/email or password']);
    exit();
  }

  // saving user id into session
  session_start();

  $_SESSION['userLoginDetails']['id'] = $row['id'];

  // save or not save login details into cookie
  if($data->rememberMe) {
    setcookie('userUsername', $row['username'], time() + (86400 * 30), '/');
    setcookie('userPassword', $row['password'], time() + (86400 * 30), '/');
  } else {
    setcookie('userUsername', '', 1, '/');
    setcookie('userPassword', '', 1, '/');
  }

  http_response_code(200);
  echo json_encode(['redirectURL' => SITE_URL]);
?>