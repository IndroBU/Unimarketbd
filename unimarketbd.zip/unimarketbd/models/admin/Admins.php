<?php
  class Admins {
    // DB stuff
    private $conn;
    private $tableName = 'admins';

    // Users Properties
    public $id;
    public $username;
    public $email;
    public $usernameEmail;
    public $password;
    public $hashedPassword;
    public $createdAt;
    public $lastUpdated;

    // Constructor with DB
    public function __construct($db) {
      $this->conn = $db;
    }

    // Read By Id
    public function readById() {
      // Create Query
      $query = "SELECT * FROM `$this->tableName` WHERE `id` = :id;";

      // Prepare statement
      $stmt = $this->conn->prepare($query);

      // Bind Param
      $stmt->bindParam(':id', $this->id);

      // Execute query
      $stmt->execute();

      return $stmt;
    }

    // Read By Username
    public function readByUsername() {
      // Create Query
      $query = "SELECT * FROM `$this->tableName` WHERE `username` = :username;";

      // Prepare statement
      $stmt = $this->conn->prepare($query);

      // Bind Param
      $stmt->bindParam(':username', $this->username);

      // Execute query
      $stmt->execute();

      return $stmt;
    }

    // Read By Email
    public function readByEmail() {
      // Create Query
      $query = "SELECT * FROM `$this->tableName` WHERE `email` = :email;";

      // Prepare statement
      $stmt = $this->conn->prepare($query);

      // Bind Param
      $stmt->bindParam(':email', $this->email);

      // Execute query
      $stmt->execute();

      return $stmt;
    }

    // Read By Username/Email
    public function readByUsernameEmail() {
      // Create Query
      $query = "SELECT * FROM `$this->tableName` WHERE `username` = :usernameEmail OR `email` = :usernameEmail;";

      // Prepare statement
      $stmt = $this->conn->prepare($query);

      // Bind Param
      $stmt->bindParam(':usernameEmail', $this->usernameEmail);

      // Execute query
      $stmt->execute();

      return $stmt;
    }

    // Read By Username and HashedPassword
    public function readByUsernameHashedPassword() {
      // Create Query
      $query = "SELECT * FROM `$this->tableName` WHERE `username` = :username AND `password` = :hashedPassword;";

      // Prepare statement
      $stmt = $this->conn->prepare($query);

      // Bind Param
      $stmt->bindParam(':username', $this->username);
      $stmt->bindParam(':hashedPassword', $this->hashedPassword);

      // Execute query
      $stmt->execute();

      return $stmt;
    }

    // Create 
    public function create() {
      // Create Query
      $query = "INSERT INTO `$this->tableName`(`username`, `email`, `password`) VALUES(:username, :email, :password);";

      // Prepare statement
      $stmt = $this->conn->prepare($query);

      // Bind Param
      $stmt->bindParam(':username', $this->username);
      $stmt->bindParam(':email', $this->email);
      $stmt->bindParam(':password', $this->password);

      // Execute query
      if($stmt->execute()) {
        return true;
      }

      return false;
    }

    // Create 
    public function updatePasswordByEmail() {
      // Create Query
      $query = "UPDATE `$this->tableName` SET `password` = :password, `lastUpdated` = now() WHERE `email` = :email;";

      // Prepare statement
      $stmt = $this->conn->prepare($query);

      // Bind Param
      $stmt->bindParam(':email', $this->email);
      $stmt->bindParam(':password', $this->password);

      // Execute query
      if($stmt->execute()) {
        return true;
      }

      return false;
    }
  }
?>