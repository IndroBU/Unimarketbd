<?php
  class Products {
    // DB stuff
    private $conn;
    private $tableName = 'products';

    // Products Properties
    public $id;
    public $name;
    public $unitPrice;
    public $shippingCost;
    public $description;
    public $hasImage;
    public $categoryId;
    public $companyId;
    public $stockUnits;
    public $createdAt;
    public $lastUpdated;

    public $q;
    public $p;
    public $rowsPerPage;

    // Constructor with DB
    public function __construct($db) {
      $this->conn = $db;
    }

    // Read All
    public function read() {
      // Create Query
      $query = "SELECT * FROM `$this->tableName`;";

      // Prepare statement
      $stmt = $this->conn->prepare($query);

      // Execute query
      $stmt->execute();

      return $stmt;
    }

    // Read By Id
    public function readById() {
      // Create Query
      $query = "SELECT * FROM `$this->tableName` WHERE `id` = :id;";

      // Prepare statement
      $stmt = $this->conn->prepare($query);

      // Bind Param
      $stmt->bindParam(':id', $this->id);

      // Execute query
      $stmt->execute();

      return $stmt;
    }

    // Read By Page
    public function readByPage() {
      $startRow = ($this->p - 1) * $this->rowsPerPage;
      $rowsPerPage = $this->rowsPerPage;

      // Create Query
      $query = "SELECT `pro`.`id`, `pro`.`name` AS `productName`, `pro`.`unitPrice`, `pro`.`shippingCost`, `pro`.`description`, `pro`.`categoryId`, `pro`.`companyId`, `pro`.`createdAt`, `pro`.`lastUpdated`, `cat`.`name` AS `categoryName`, `com`.`name` AS `companyName`, `pro`.`stockUnits` FROM `$this->tableName` `pro`, `categories` `cat`, `companies` `com` WHERE (`pro`.`categoryId` = `cat`.`id`) AND (`pro`.`companyId` = `com`.`id`) ORDER BY `pro`.`createdAt` DESC LIMIT $startRow, $rowsPerPage;";

      // Prepare statement
      $stmt = $this->conn->prepare($query);

      // Execute query
      $stmt->execute();

      return $stmt;
    }

    // Read By Page & Q
    public function readByPageQ() {
      $startRow = ($this->p - 1) * $this->rowsPerPage;
      $rowsPerPage = $this->rowsPerPage;

      // Create Query
      $query = "SELECT `pro`.`id`, `pro`.`name` AS `productName`, `pro`.`unitPrice`, `pro`.`shippingCost`, `pro`.`description`, `pro`.`categoryId`, `pro`.`companyId`, `pro`.`createdAt`, `pro`.`lastUpdated`, `cat`.`name` AS `categoryName`, `com`.`name` AS `companyName`, `pro`.`stockUnits` FROM `$this->tableName` `pro`, `categories` `cat`, `companies` `com` WHERE ((`pro`.`name` LIKE :q) OR (`cat`.`name` LIKE :q) OR (`com`.`name` LIKE :q)) AND (`pro`.`categoryId` = `cat`.`id`) AND (`pro`.`companyId` = `com`.`id`) ORDER BY `pro`.`createdAt` DESC LIMIT $startRow, $rowsPerPage;";

      // Prepare statement
      $stmt = $this->conn->prepare($query);

      // Bind Param
      $stmt->bindParam(':q', $this->q);

      // Execute query
      $stmt->execute();

      return $stmt;
    }

    // Create 
    public function create() {
      // Create Query
      $query = "INSERT INTO `$this->tableName`(`name`, `unitPrice`, `shippingCost`, `description`, `categoryId`, `companyId`, `stockUnits`) VALUES(:name, :unitPrice, :shippingCost, :description, :categoryId, :companyId, :stockUnits);";

      // Prepare statement
      $stmt = $this->conn->prepare($query);

      // Bind Param
      $stmt->bindParam(':name', $this->name);
      $stmt->bindParam(':unitPrice', $this->unitPrice);
      $stmt->bindParam(':shippingCost', $this->shippingCost);
      $stmt->bindParam(':description', $this->description);
      $stmt->bindParam(':categoryId', $this->categoryId);
      $stmt->bindParam(':companyId', $this->companyId);
      $stmt->bindParam(':stockUnits', $this->stockUnits);

      // Execute query
      if($stmt->execute()) {
        return true;
      }

      return false;
    }

    // Update 
    public function update() {
      // Create Query
      $query = "UPDATE `$this->tableName` SET `name` = :name, `unitPrice` = :unitPrice, `shippingCost` = :shippingCost, `description` = :description, `categoryId` = :categoryId, `companyId` = :companyId, `stockUnits` = :stockUnits WHERE id = :id;";

      // Prepare statement
      $stmt = $this->conn->prepare($query);

      // Bind Param
      $stmt->bindParam(':id', $this->id);
      $stmt->bindParam(':name', $this->name);
      $stmt->bindParam(':unitPrice', $this->unitPrice);
      $stmt->bindParam(':shippingCost', $this->shippingCost);
      $stmt->bindParam(':description', $this->description);
      $stmt->bindParam(':categoryId', $this->categoryId);
      $stmt->bindParam(':companyId', $this->companyId);
      $stmt->bindParam(':stockUnits', $this->stockUnits);

      // Execute query
      if($stmt->execute()) {
        return true;
      }

      return false;
    }

    // Create 
    public function updateHasImageById() {
      // Create Query
      $query = "UPDATE `$this->tableName` SET `hasImage` = :hasImage WHERE `id` = :id;";

      // Prepare statement
      $stmt = $this->conn->prepare($query);

      // Bind Param
      $stmt->bindParam(':id', $this->id);

      // Execute query
      if($stmt->execute()) {
        return true;
      }

      return false;
    }

    // Create 
    public function updateStockUnitsById() {
      // Create Query
      $query = "UPDATE `$this->tableName` SET `stockUnits` = :stockUnits WHERE `id` = :id;";

      // Prepare statement
      $stmt = $this->conn->prepare($query);

      // Bind Param
      $stmt->bindParam(':stockUnits', $this->stockUnits);
      $stmt->bindParam(':id', $this->id);

      // Execute query
      if($stmt->execute()) {
        return true;
      }

      return false;
    }

    // Delete 
    public function delete() {
      // Create Query
      $query = "DELETE FROM `$this->tableName` WHERE `id` = :id;";

      // Prepare statement
      $stmt = $this->conn->prepare($query);

      // Bind Param
      $stmt->bindParam(':id', $this->id);

      // Execute query
      if($stmt->execute()) {
        return true;
      }

      return false;
    }
  }
?>