var wishlistIcon = $('#wishlist-icon');
var wishlistItems = $('#wishlist-items'); 

var addToWishlistProcessing = false;
var removeFromWishlistProcessing = false;

function prependProductIntoWishlist(product) {
  var wishlistItem = $(document.createElement('li'));
  wishlistItem.attr('class', 'wishlist-item');

  wishlistItem.html(`<form data-product-id='${product.id}' onsubmit='removeFromWishlist(event)' method='POST' class='d-flex align-items-center product wishlist-item-form'>
    <img width='60' src='${product.imgURL.substring(4)}' class='mr-5 wishlist-product-img'/>
    <div class='d-flex flex-column wishlist-product-info'>
      <span class='text-primary wishlist-product-name'>${product.name}</span>
      <span class='wishlist-product-price-cost'>${product.unitPrice} TK (+${product.shippingCost} TK)</span>
    </div>
    <button type='button' onclick='addToCart(event)' class='btn btn-info shadow-none ml-auto add-to-cart-btn-from-wishlist'>
      Add to cart
    </button>
    <button class='btn btn-danger shadow-none ml-2 remove-product-from-wishlist-btn'>
      Remove
    </button>
  </form>`);

  wishlistItems.prepend(wishlistItem);
}

function addToWishlist(event) {
  if(addToWishlistProcessing) return;

  var productId = $(event.target).closest('.product').attr('data-product-id');

  $.ajax({
    url: './api/user/add-to-wishlist.php',
    method: 'POST',
    data: JSON.stringify({
      productId
    }),
    beforeSend: function() {
      addToWishlistProcessing = true;
    },
    success: function(res) {
      var curWishlistCount = parseInt(wishlistIcon.attr('data-wishlist-count'));
      curWishlistCount = curWishlistCount > 9 ? '9+' : curWishlistCount + 1;
      wishlistIcon.attr('data-wishlist-count', curWishlistCount);

      if($('#no-wishlist-item')) $('#no-wishlist-item').remove();

      showToastNotification(res.product.name + ' has been added to your wishlist');
      prependProductIntoWishlist(res.product);
    },
    error: function(err) {
      (err.responseJSON.redirectURL) ? window.location.href = err.responseJSON.redirectURL : showToastNotification(err.responseJSON.message);
    },
    complete: function() {
      addToWishlistProcessing = false;
    }
  });
}

function removeFromWishlist(event) {
  event.preventDefault();

  if(removeFromWishlistProcessing) return;

  var productId = $(event.target).attr('data-product-id');

  $.ajax({
    url: './api/user/remove-from-wishlist.php',
    method: 'POST',
    data: JSON.stringify({
      productId
    }),
    beforeSend: function() {
      removeFromWishlistProcessing = true;
    },
    success: function(res) {
      var curWishlistCount = Number(wishlistIcon.attr('data-wishlist-count'));
      curWishlistCount = (curWishlistCount - 1) > 9 ? '9+' : curWishlistCount - 1;
      wishlistIcon.attr('data-wishlist-count', curWishlistCount);

      showToastNotification(res.message);
      
      var wishlistItem = $(event.target).closest('.wishlist-item');
      wishlistItem.remove();

      if(!wishlistItems.find('li').length) {
        wishlistItems.html("<div class='no-wishlist-item text-center' id='no-wishlist-item'>No products added into wishlist yet</div>");
      }
    },
    error: function(err) {
      showToastNotification(err.responseJSON.message);
    },
    complete: function() {
      removeFromWishlistProcessing = false;
    }
  });
}