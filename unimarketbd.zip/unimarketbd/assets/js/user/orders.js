var changeOrderStatusProcessing = false;

function changeOrderStatus(orderId) {
  $.ajax({
    url: './api/admin/update-order-status.php',
    method: 'POST',
    data: JSON.stringify({
      orderId,
      status: 'Returned'
    }),
    beforeSend: function() {
      changeOrderStatusProcessing = true;
    },
    success: function(res) {
      location.reload();
    },
    error: function(err) {
      console.log(err);
    },
    complete: function() {
      changeOrderStatusProcessing = false;
    }
  });
}