var cartIcon = $('#cart-icon');
var cartItems = $('#cart-items'); 
var cartTotalCostContainer = $('#cart-total-cost-container');
var orderNowForm = $('#order-now-form');
var orderNowBtn = $('#order-now-btn');
var cartTotalCost = $('#cart-total-cost');
var paymentMethodsWrapper = $('.payment-methods-wrapper');
var deliveryTypeInp = $('[name="delivery-type-inp"]');
var paymentMethodInp = $('.payment-method-inp');

var addToCartProcessing = false;
var removeFromCartProcessing = false;

function prependProductIntoCart(product) {
  var cartItem = $(document.createElement('li'));
  cartItem.attr('class', 'cart-item');

  cartItem.html(`<form data-product-id='${product.id}' onsubmit='removeFromCart(event)' method='POST' class='d-flex align-items-center cart-item-form'>
    <img width='60' src='${product.imgURL.substring(4)}' class='mr-2 cart-product-img'/>
    <div class='d-flex flex-column cart-product-info'>
      <span class='text-primary cart-product-name'>${product.name}</span>
      <span class='cart-product-price-cost'>${product.unitPrice} TK (+${product.shippingCost} TK)</span>
    </div>
    <span class='ml-2 cart-multiply-icon'>x</span>
    <input oninput='updateCart(event)' type='number' class='ml-2 form-control shadow-none cart-quantity-inp' id='cart-quantity-inp-${product.id}' min='1' value='${product.quantity}'/>
    <span class='ml-2 cart-equal-icon'>=</span>
    <span class='ml-2 cart-individual-total' id='cart-individual-total-${product.id}'>${product.individualCost} TK</span>
    <button class='btn btn-danger ml-auto remove-product-from-cart-btn'>Remove</button>
  </form>`);

  cartItems.prepend(cartItem);
}

function addToCart(event) {
  if(addToCartProcessing) return;

  var productId = $(event.target).closest('.product').attr('data-product-id');
  var quantity = 1;

  if($(`#cart-quantity-inp-${productId}`).length) {
    quantity = parseInt($(`#cart-quantity-inp-${productId}`).val()) + 1;
  }

  $.ajax({
    url: './api/user/add-to-cart.php',
    method: 'POST',
    data: JSON.stringify({
      productId,
      quantity
    }),
    beforeSend: function() {
      addToCartProcessing = true;
    },
    success: function(res) {
      var cartItemsCount = res.product.totalCartItems;
      cartItemsCount = cartItemsCount > 9 ? '9+' : cartItemsCount;
      cartIcon.attr('data-cart-count', cartItemsCount == null ? 0 : cartItemsCount);

      showToastNotification(res.product.quantity + ' x ' + res.product.name + ' has been added to your cart');

      switch (res.product.operationType) {
        case 'Created':
          if($('#no-cart-item').length) $('#no-cart-item').remove();
          prependProductIntoCart(res.product);

          cartTotalCostContainer.removeClass('d-none');
          orderNowForm.removeClass('d-none');
          break;

        case 'Updated':
          $(`#cart-quantity-inp-${res.product.id}`).attr('value', res.product.quantity);
          $(`#cart-individual-total-${res.product.id}`).text('$'+res.product.individualCost);
          break;
      }

      cartTotalCost.text(res.product.totalCost);
    },
    error: function(err) {
      (err.responseJSON.redirectURL) ? window.location.href = err.responseJSON.redirectURL : showToastNotification(err.responseJSON.message);
    },
    complete: function() {
      addToCartProcessing = false;
    }
  });
}

function updateCart(event) {
  if(addToCartProcessing) return;

  var productId = $(event.target).closest('form').attr('data-product-id');
  var quantity = parseInt($(event.target).val());

  if(isNaN(quantity)) quantity = 1;

  console.log(quantity);

  $.ajax({
    url: './api/user/add-to-cart.php',
    method: 'POST',
    data: JSON.stringify({
      productId,
      quantity
    }),
    beforeSend: function() {
      addToCartProcessing = true;
    },
    success: function(res) {
      console.log(res);

      var cartItemsCount = res.product.totalCartItems;
      cartItemsCount = cartItemsCount > 9 ? '9+' : cartItemsCount;
      cartIcon.attr('data-cart-count', cartItemsCount == null ? 0 : cartItemsCount);

      showToastNotification(res.product.quantity + ' x ' + res.product.name + ' has been added to your cart');
      
      $(event.target).val(res.product.quantity);
      $(`#cart-individual-total-${res.product.id}`).text('$'+res.product.individualCost);

      cartTotalCost.text(res.product.totalCost);
    },
    error: function(err) {
      showToastNotification(err.responseJSON.message);
    },
    complete: function() {
      addToCartProcessing = false;
    }
  });
}

function removeFromCart(event) {
  event.preventDefault();

  if(removeFromCartProcessing) return;

  var productId = $(event.target).attr('data-product-id');

  $.ajax({
    url: './api/user/remove-from-cart.php',
    method: 'POST',
    data: JSON.stringify({
      productId
    }),
    beforeSend: function() {
      removeFromCartProcessing = true;
    },
    success: function(res) {
      var cartItemsCount = res.totalCartItems;
      cartItemsCount = cartItemsCount > 9 ? '9+' : cartItemsCount;
      cartIcon.attr('data-cart-count', cartItemsCount == null ? 0 : cartItemsCount);

      showToastNotification(res.message);
      
      var cartItem = $(event.target).closest('.cart-item');
      cartItem.remove();

      cartTotalCost.text(res.totalCost);

      if(!cartItems.find('li').length) {
        cartTotalCostContainer.addClass('d-none');
        orderNowForm.addClass('d-none');

        cartItems.prepend("<div class='no-cart-item text-center' id='no-cart-item'>No products added into cart yet</div>");
      }
    },
    error: function(err) {
      showToastNotification(err.responseJSON.message);
    },
    complete: function() {
      removeFromCartProcessing = false;
    }
  });
}

function createOrder(event) {
  event.preventDefault();

  var shippingPointId = $('#order-shipping-point').val();
  var paymentMethodId = $('[name="delivery-type-inp"]:checked').val() == 'cash-on' ? '' : $('[name="payment-method-inp"]:checked').val();
  var userLocation = $('#user-location').val();
  var phoneNum = $('#user-phone-num').val();

  $.ajax({
    url: './api/user/create-order.php',
    method: 'POST',
    data: JSON.stringify({
      shippingPointId,
      paymentMethodId,
      userLocation,
      phoneNum
    }),
    beforeSend: function() {
      orderNowBtn.attr('disabled', 'disabled');
    },
    success: function (res) {
      showToastNotification('Congratulations! Your order has been successfully placed.');
      setTimeout(() => window.location.href = res.redirectURL, 3000);
    },
    error: function(err) {
      showToastNotification(err.responseJSON.message);
    },
    complete: function() {
      orderNowBtn.removeAttr('disabled');
    }
  });
}

deliveryTypeInp.on('change', function(e){
  switch($(e.target).val()) {
    case 'cashless':
      paymentMethodsWrapper.removeClass('d-none d-flex').addClass('d-flex');
      paymentMethodInp.attr('required', '');
      break;
    case 'cash-on':
      paymentMethodsWrapper.removeClass('d-none d-flex').addClass('d-none');
      paymentMethodInp.removeAttr('required');
      break;
  }
});