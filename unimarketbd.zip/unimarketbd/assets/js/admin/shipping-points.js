var createShippingPointForm = $('#create-shipping-point-form');
var createShippingPointBtn = $('#create-shipping-point-btn');
var createShippingPointResMsgContainer = $('#create-shipping-point-form .res-msg-container');

var deleteShippingPointForm = $('#delete-shipping-point-form');
var deleteShippingPointBtn = $('#delete-shipping-point-btn');
var deleteShippingPointResMsgContainer = $('#delete-shipping-point-form .res-msg-container');

function createShippingPoint(event) {
  event.preventDefault();

  $.ajax({
    url: '../api/admin/create-shipping-point.php',
    method: 'POST',
    data: JSON.stringify({
      name: $('#create-shipping-point-name').val(),
      location: $('#create-shipping-point-location').val(),
      description: $('#create-shipping-point-desc').val()
    }),
    beforeSend: function() {
      createShippingPointBtn.attr('disabled', 'disabled');
    },
    success: function(res) {
      window.location.href = res.redirectURL;
    },
    error: function(err) {
      createShippingPointResMsgContainer.html(`<span class="text-danger">${err.responseJSON.message}</span>`);
      createShippingPointResMsgContainer.removeClass('d-none');
    },
    complete: function() {
      createShippingPointBtn.removeAttr('disabled');
    }
  });
}

function deleteShippingPointPre(event) {
  var id = $(event.target).tagName == 'button' ? $(event.target).attr('data-shipping-point-id') :  $(event.target).closest('button').attr('data-shipping-point-id');
  deleteShippingPointForm.attr('data-shipping-point-id', id);
}

function deleteShippingPoint(event) {
  event.preventDefault();

  $.ajax({
    url: '../api/admin/delete-shipping-point.php',
    method: 'DELETE',
    data: JSON.stringify({
      id: deleteShippingPointForm.attr('data-shipping-point-id')
    }),
    beforeSend: function() {
      deleteShippingPointBtn.attr('disabled', 'disabled');
    },
    success: function(res) {
      window.location.href = res.redirectURL;
    },
    error: function(err) {
      deleteShippingPointResMsgContainer.html(`<span class="text-danger">${err.responseJSON.message}</span>`);
      deleteShippingPointResMsgContainer.removeClass('d-none');
    },
    complete: function() {
      deleteShippingPointBtn.removeAttr('disabled');
    }
  });
}