<?php
  function getByPageCompanies($curPageNo) {
    // instantiate db & connect
    $database = new Database();
    $db = $database->connect();

    // instantiate Companies object
    $companies = new Companies($db);

    // set properties
    $companies->p = $curPageNo;
    $companies->rowsPerPage = (int) ADMIN_ROWS_PER_PAGE;

    // get companies by page
    $stmt = $companies->readByPage();
    $rowCount = $stmt->rowCount();

    if(!$rowCount) return false;

    $companies = $stmt->fetchAll(PDO::FETCH_ASSOC);

    return $companies;
  }
?>