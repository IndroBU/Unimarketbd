<?php
  function getPageCountCategories() {
    // instantiate db & connect
    $database = new Database();
    $db = $database->connect();

    // instantiate Categories object
    $categories = new Categories($db);

    // get all categories
    $stmt = $categories->read();
    $rowCount = $stmt->rowCount();

    $totalPages = ceil($rowCount / (int) ADMIN_ROWS_PER_PAGE);

    return $totalPages;
  }
?>