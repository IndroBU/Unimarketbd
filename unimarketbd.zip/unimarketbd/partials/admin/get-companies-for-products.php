<?php
  function getCompaniesForProducts() {
    // instantiate db & connect
    $database = new Database();
    $db = $database->connect();

    // instantiate Companies object
    $companies = new Companies($db);

    // get all companies
    $stmt = $companies->read();
    $rowCount = $stmt->rowCount();

    if(!$rowCount) return false;

    $companies = $stmt->fetchAll(PDO::FETCH_ASSOC);

    print_r($companies);

    return $companies;
  }
?>