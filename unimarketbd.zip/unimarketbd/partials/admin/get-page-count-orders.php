<?php
  function getPageCountOrders() {
    // instantiate db & connect
    $database = new Database();
    $db = $database->connect();

    // instantiate Orders object
    $orders = new Orders($db);

    // get all orders
    $stmt = $orders->read();
    $rowCount = $stmt->rowCount();

    $totalPages = ceil($rowCount / (int) ADMIN_ROWS_PER_PAGE);

    return $totalPages;
  }
?>