<?php
  function getByPageUsers($curPageNo) {
    // instantiate db & connect
    $database = new Database();
    $db = $database->connect();

    // instantiate Users object
    $users = new Users($db);

    // set properties
    $users->p = $curPageNo;
    $users->rowsPerPage = (int) ADMIN_ROWS_PER_PAGE;

    // get users by page
    $stmt = $users->readByPage();
    $rowCount = $stmt->rowCount();

    if(!$rowCount) return false;

    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);

    return $users;
  }
?>