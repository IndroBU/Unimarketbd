<?php
  function getCategoriesCount() {
    // instantiate db & connect
    $database = new Database();
    $db = $database->connect();

    // instantiate Categories object
    $categories = new Categories($db);

    // get all categories
    $stmt = $categories->read();
    $rowCount = $stmt->rowCount();

    return $rowCount;
  }

  function getCompaniesCount() {
    // instantiate db & connect
    $database = new Database();
    $db = $database->connect();

    // instantiate Companies object
    $companies = new Companies($db);

    // get all companies
    $stmt = $companies->read();
    $rowCount = $stmt->rowCount();

    return $rowCount;
  }

  function getProductsCount() {
    // instantiate db & connect
    $database = new Database();
    $db = $database->connect();

    // instantiate Products object
    $products = new Products($db);

    // get all products
    $stmt = $products->read();
    $rowCount = $stmt->rowCount();

    return $rowCount;
  }

  function getShippingPointsCount() {
    // instantiate db & connect
    $database = new Database();
    $db = $database->connect();

    // instantiate Shipping Points object
    $shippingPoints = new ShippingPoints($db);

    // get all shippingPoints
    $stmt = $shippingPoints->read();
    $rowCount = $stmt->rowCount();

    return $rowCount;
  }
?>