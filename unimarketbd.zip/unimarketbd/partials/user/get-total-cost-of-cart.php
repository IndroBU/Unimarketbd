<?php
  function getTotalCostOfCart() {
    if(!isset($_SESSION['userLoginDetails']['id']) || !isset($_SESSION['userLoginDetails']['orderId'])) return;

    // instantiate db & connect
    $database = new Database();
    $db = $database->connect();

    // instantiate Cart object
    $cart = new Cart($db);

    // set properties
    $cart->orderId = $_SESSION['userLoginDetails']['orderId'];

    // get all cart items
    $stmt = $cart->readTotalCost();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    return $row['totalCost'];
  }
?>