<?php
  function getOrderIds() {
    // instantiate db & connect
    $database = new Database();
    $db = $database->connect();

    // instantiate Orders object
    $orders = new Orders($db);

    // set properties
    $orders->userId = $_SESSION['userLoginDetails']['id'];

    // get all order ids of the user
    $orderIdsStmt = $orders->readTotalOrdersOfUser();

    if(!$orderIdsStmt->rowCount()) return false;

    $orderIds = $orderIdsStmt->fetchAll(PDO::FETCH_ASSOC);

    return $orderIds;
  }
?>