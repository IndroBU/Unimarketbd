<?php
  function getShippingPoints() {
    if(!isset($_SESSION['userLoginDetails']['id']) || !isset($_SESSION['userLoginDetails']['orderId'])) return;

    // instantiate db & connect
    $database = new Database();
    $db = $database->connect();

    // instantiate ShippingPoints object
    $shippingPoints = new ShippingPoints($db);

    // get all shipping points
    $stmt = $shippingPoints->read();
    $row = $stmt->fetchAll(PDO::FETCH_ASSOC);

    return $row;
  }
?>