<?php
  function showShippingPoints($shippingPoints) {
    $html = "";

    if($shippingPoints) {
      foreach ($shippingPoints as $shippingPoint) {
        extract($shippingPoint);

        $html .= "<option value='$id'>#$id $name</option>";
      }
    }

    return $html;
  }

  function showPaymentMethods($paymentMethods) {
    $html = "<div class='payment-methods-wrapper d-none justify-content-center mb-3'>";

    foreach($paymentMethods as $paymentMethod) {
      $html .= "<div class='payment-methods-item mx-2'>
        <label for='payment-method-". $paymentMethod['id'] ."'>
          <input type='radio' class='payment-method-inp d-none' name='payment-method-inp' value='". $paymentMethod['id'] ."' id='payment-method-". $paymentMethod['id'] ."'/>
          <img width='64' class='payment-method-img rounded img-fluid' src='". SITE_URL ."/". $paymentMethod['pic'] ."' alt='". $paymentMethod['name'] ."'/>
        </label>
      </div>";
    }

    $html .= "</div>";

    return $html;
  }

  function showCartItems($products) {
    $html = "";

    if(!$products) {
      $html .= "<div class='no-cart-item text-center' id='no-cart-item'>No products added into cart yet</div>";
    }

    if($products) {
      foreach ($products as $product) {
        extract($product);
  
        $imgURL = glob("./assets/img/shared/products/$id.*")[0];
  
        $html .= 
        "<li class='cart-item'>
          <form data-product-id='$id' onsubmit='removeFromCart(event)' method='POST' class='d-flex align-items-center cart-item-form'>
            <img width='60' src='$imgURL' class='mr-2 cart-product-img'/>
            <div class='d-flex flex-column cart-product-info'>
              <span class='text-primary cart-product-name'>$name</span>
              <span class='cart-product-price-cost'>$unitPrice TK (+$shippingCost TK)</span>
            </div>
            <span class='ml-2 cart-multiply-icon'>x</span>
            <input oninput='updateCart(event)' type='number' class='ml-2 form-control shadow-none cart-quantity-inp' id='cart-quantity-inp-".$id."' min='1' value='$quantity'/>
            <span class='ml-2 cart-equal-icon'>=</span>
            <span class='ml-2 cart-individual-total' id='cart-individual-total-".$id."'>$individualCost TK</span>
            <button class='btn btn-danger ml-auto remove-product-from-cart-btn'>Remove</button>
          </form>
        </li>";
      }
    }

    $hideTwoSectionsBelow = !$products ? 'd-none' : '';

    $html .=
    "<div class='$hideTwoSectionsBelow mt-5 pt-3 border-top text-center cart-total-cost-container' id='cart-total-cost-container'>
      <span>
        Total: <span class='cart-total-cost' id='cart-total-cost'>".getTotalCostOfCart()." TK</span>
      </span>
    </div>";

    $html .=
    "<form onsubmit='createOrder(event)' class='$hideTwoSectionsBelow mt-3 w-75 mx-auto text-center order-now-form' id='order-now-form'>
      <div class='delivery-type-wrapper d-flex justify-content-center mb-3'>
        <div class='delivery-type-item d-flex align-items-center mr-4'>
          <input name='delivery-type-inp' type='radio' class='cash-on-delivery' id='cash-on-delivery' value='cash-on' required checked/>
          <label for='cash-on-delivery' class='ml-2 mb-0'>Cash On Delivery</label>
        </div>
        <div class='delivery-type-item d-flex align-items-center'>
          <input name='delivery-type-inp' type='radio' class='cashless-delivery' id='cashless-delivery' value='cashless' required/>
          <label for='cashless-delivery' class='ml-2 mb-0'>Cashless Delivery</label>
        </div>
      </div>
      ". showPaymentMethods(getPaymentMethods()) ."
      <select required class='mb-3 form-control shadow-none order-shipping-point' id='order-shipping-point'>
        <option value=''>Select a Shipping Point</option>
        ".showShippingPoints(getShippingPoints())."
      </select>
      <input type='text' required class='mb-3 form-control shadow-none user-location' id='user-location' placeholder='Your location'/>
      <input type='tel' required class='mb-3 form-control shadow-none user-phone-num' id='user-phone-num' placeholder='Your phone number'/>
      <button class='btn btn-primary order-now-btn' id='order-now-btn'>Order Now</button>
    </form>";

    return $html;
  }

  function cartModal() {
    $html = isset($_SESSION['userLoginDetails']) ?
    "<div class='modal fade' id='cartModal' tabindex='-1' role='dialog'>
      <div class='modal-dialog' role='document'>
        <div class='p-4 modal-content'>
          <span class='position-absolute modal-cross' data-dismiss='modal'>
            <i class='fas fa-times'></i>
          </span>
          <h3 class='my-4 text-primary text-center modal-heading'>My cart</h3>
          <ul class='mb-0 list-unstyled cart-items' id='cart-items'>
            ".showCartItems(getCart())."
          </ul>
        </div>
      </div>
    </div>" : 
    "<div class='modal fade' id='cartModal' tabindex='-1' role='dialog'>
      <div class='modal-dialog' role='document'>
        <div class='p-4 modal-content'>
          <span class='position-absolute modal-cross' data-dismiss='modal'>
            <i class='fas fa-times'></i>
          </span>
          <h3 class='my-4 text-dark text-center modal-heading'>Please, login to see your cart</h3>
          <a href='".SITE_URL."/login.php' class='btn btn-primary align-self-center'>Login</a>
        </div>
      </div>
    </div>";

    return $html;
  }
?>