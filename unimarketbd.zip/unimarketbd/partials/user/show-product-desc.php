<div class="modal fade" id="showProductDescModal" tabindex="-1" role="dialog" aria-modal="true">
  <div class="modal-dialog" role="document" style="max-width: 700px; width: 100%;">
    <div class="p-4 modal-content">
      <span class="position-absolute modal-cross" data-dismiss="modal">
        <svg class="svg-inline--fa fa-times fa-w-11" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="times" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 352 512" data-fa-i2svg=""><path fill="currentColor" d="M242.72 256l100.07-100.07c12.28-12.28 12.28-32.19 0-44.48l-22.24-22.24c-12.28-12.28-32.19-12.28-44.48 0L176 189.28 75.93 89.21c-12.28-12.28-32.19-12.28-44.48 0L9.21 111.45c-12.28 12.28-12.28 32.19 0 44.48L109.28 256 9.21 356.07c-12.28 12.28-12.28 32.19 0 44.48l22.24 22.24c12.28 12.28 32.2 12.28 44.48 0L176 322.72l100.07 100.07c12.28 12.28 32.2 12.28 44.48 0l22.24-22.24c12.28-12.28 12.28-32.19 0-44.48L242.72 256z"></path></svg>
      </span>
      <div class="row align-items-center">
        <div class="col-6">
          <img height="320" width="100%" class="product-desc__product-img" src="http://localhost/unimarketbd/assets/img/shared/products/16.jpg" alt="" srcset="">
        </div>
        <div class="col-6">
          <h5 class="product-desc__product-name text-primary">Mango - 1kg</h5>
          <h6 class="product-desc__category-name"></h6>
          <h6 class="product-desc__company-name"></h6>
          <h4 class="product-desc__product-price font-weight-bold mt-4"></h4>
        </div>
      </div>
      <div class="border-top mt-2 pt-2">
        <p class="product-desc_product-desc"></p>
      </div>
    </div>
  </div>
</div>