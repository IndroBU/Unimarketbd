<?php
  function showWishlistItems($products) {
    $html = "";

    if(!$products) {
      return "<div class='no-wishlist-item text-center' id='no-wishlist-item'>No products added into wishlist yet</div>";
    }

    foreach ($products as $product) {
      extract($product);

      $imgURL = glob("./assets/img/shared/products/$id.*")[0];

      $html .= 
      "<li class='wishlist-item'>
        <form data-product-id='$id' onsubmit='removeFromWishlist(event)' method='POST' class='d-flex align-items-center  wishlist-item-form product' data-product-id='$id'>
          <img width='60' src='$imgURL' class='mr-5 wishlist-product-img'/>
          <div class='d-flex flex-column wishlist-product-info'>
            <span class='text-primary wishlist-product-name'>$name</span>
            <span class='wishlist-product-price-cost'>$unitPrice TK (+$shippingCost TK)</span>
          </div>
          <button type='button' onclick='addToCart(event)' class='btn btn-info shadow-none ml-auto add-to-cart-btn-from-wishlist'>
            Add to cart
          </button>
          <button class='btn btn-danger shadow-none ml-2 remove-product-from-wishlist-btn'>
            Remove
          </button>
        </form>
      </li>";
    }

    return $html;
  }

  function wishlistModal() {
    $html = isset($_SESSION['userLoginDetails']) ?
    "<div class='modal fade' id='wishlistModal' tabindex='-1' role='dialog'>
      <div class='modal-dialog' role='document'>
        <div class='p-4 modal-content'>
          <span class='position-absolute modal-cross' data-dismiss='modal'>
            <i class='fas fa-times'></i>
          </span>
          <h3 class='my-4 text-primary text-center modal-heading'>My Wishlist</h3>
          <ul class='mb-0 list-unstyled wishlist-items' id='wishlist-items'>
            ".showWishlistItems(getWishlist())."
          </ul>
        </div>
      </div>
    </div>" : 
    "<div class='modal fade' id='wishlistModal' tabindex='-1' role='dialog'>
      <div class='modal-dialog' role='document'>
        <div class='p-4 modal-content'>
          <span class='position-absolute modal-cross' data-dismiss='modal'>
            <i class='fas fa-times'></i>
          </span>
          <h3 class='my-4 text-dark text-center modal-heading'>Please, login to see your wishlist</h3>
          <a href='".SITE_URL."/login.php' class='btn btn-primary align-self-center'>Login</a>
        </div>
      </div>
    </div>";

    return $html;
  }
?>