<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- Shared -->
  <link rel="stylesheet" href="./assets/css/shared/bootstrap.min.css">
  <link rel="stylesheet" href="./assets/css/shared/main.css">
  <!-- User -->
  <link rel="stylesheet" href="./assets/css/user/header.css">
  <link rel="stylesheet" href="./assets/css/user/forgot-password.css">
  <title>UnimarketBd | Forgot Password</title>
</head>
<body>
  <?php
    session_start();

    include_once './config/Constants.php';
    include_once './config/Database.php';
    include_once './models/user/Users.php';
    include_once './partials/user/login-with-cookie.php';
    include_once './partials/user/wishlist-modal.php';
    include_once './partials/user/cart-modal.php';
    include_once './partials/user/orders-modal.php';
    include_once './partials/user/header.php';
    include_once './partials/user/get-wishlist-count.php';
    include_once './partials/user/get-cart-count.php';
    include_once './partials/user/get-orders-count.php';
    include_once './partials/user/footer.php';
  ?>

  <?php
    loginWithCookie();

    if(isset($_SESSION['userLoginDetails'])) header('location: '.SITE_URL);
  ?>

  <?php echo wishlistModal(); ?> <!-- Render wishlist modal -->
  <?php echo cartModal(); ?> <!-- Render cart modal -->
  <?php echo ordersModal(); ?> <!-- Render orders modal -->

  <?php echo headerHTML(); ?>
  <section class="forgot-password-section">
    <div class="container">
      <h1 class="mb-5 text-center text-primary forgot-password-heading">Forgot Password</h1>

      <form onsubmit="emailVerification(event)" class="bg-white rounded mx-auto p-5 email-verification-form" id="email-verification-form">
        <div class="form-group">
          <label for="email">Enter Your Email</label>
          <input required type="email" class="shadow-none form-control email" id="email">
          <span class="link-sent-text">* An email will be sent with recovery code</span>
        </div>
        <button class="mt-3 shadow-none btn btn-primary verify-btn" id="verify-btn">Submit</button>
        <div class="d-none mt-4 text-center res-msg-container">
          <!-- response goes here -->
        </div>
      </form>

      <form onsubmit="matchRecoveryCode(event)" class="bg-white d-none rounded mx-auto p-5 match-recovery-code-form" id="match-recovery-code-form">
        <div class="form-group">
          <label for="recovery-code">Recovery Code</label>
          <input type="text" class="shadow-none form-control recovery-code" id="recovery-code">
          <span class="link-sent-text">* An email has been sent with the recovery code</span>
        </div>
        <button class="mt-3 shadow-none btn btn-primary match-recovery-code-btn" id="match-recovery-code-btn">Submit</button>
        <div class="d-none mt-4 text-center res-msg-container">
          <!-- response goes here -->
        </div>
      </form>

      <form onsubmit="resetPassword(event)" class="bg-white d-none rounded mx-auto p-5 reset-password-form" id="reset-password-form">
        <div class="form-group">
          <label for="password-new">New Password</label>
          <input required minlength="8" maxlength="20" type="password" class="shadow-none form-control password-new" id="password-new">
        </div>
        <div class="form-group">
          <label for="password-confirm">Confirm Password</label>
          <input required minlength="8" maxlength="20" type="password" class="shadow-none form-control password-confirm" id="password-confirm">
        </div>
        <button class="mt-3 shadow-none btn btn-primary reset-password-btn" id="reset-password-btn">Reset</button>
        <div class="d-none mt-4 text-center res-msg-container">
          <!-- response goes here -->
        </div>
      </form>
    </div>
  </section>

  <?php echo footer(); ?> <!-- Render footer -->

  <!-- Shared -->
  <script src="./assets/js/shared/font-awesome.min.js"></script>
  <script src="./assets/js/shared/jquery.min.js"></script>
  <script src="./assets/js/shared/bootstrap.bundle.min.js"></script>
  <script src="./assets/js/shared/main.js"></script>
  <!-- User -->
  <script src="./assets/js/user/forgot-password.js"></script>
</body>
</html>