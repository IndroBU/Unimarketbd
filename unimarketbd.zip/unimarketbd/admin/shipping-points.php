<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- Shared -->
  <link rel="stylesheet" href="../assets/css/shared/bootstrap.min.css">
  <link rel="stylesheet" href="../assets/css/shared/main.css">
  <!-- Admin -->
  <link rel="stylesheet" href="../assets/css/admin/sidebar.css">
  <link rel="stylesheet" href="../assets/css/admin/nav.css">
  <link rel="stylesheet" href="../assets/css/admin/shipping-points.css">
  <title>UnimarketBd Admin | Shipping Points</title>
</head>
<body>
  <?php
    session_start();

    include_once '../config/Constants.php';
    include_once '../config/Database.php';
    include_once '../models/admin/Admins.php';
    include_once '../models/admin/ShippingPoints.php';
    include_once '../partials/admin/sidebar.php';
    include_once '../partials/admin/nav.php';
    include_once '../partials/admin/login-with-cookie.php';
    include_once '../partials/admin/get-page-count-shipping-points.php';
    include_once '../partials/admin/get-by-page-shipping-points.php';
    include_once '../partials/admin/get-farthest-page-no.php';
  ?>

  <?php
    loginWithCookie();

    if(!isset($_SESSION['adminLoginDetails'])) header('location: ./login.php');
  ?>

  <?php
    if(!isset($_GET['p'])) header('location: ./shipping-points.php?p=1');

    $curPageNo = (int) $_GET['p'];

    $maxPages = getPageCountShippingPoints();

    if(($curPageNo != 1) && ($curPageNo < 1 || $curPageNo > $maxPages)) header('location: ./shipping-points.php?p=1');

    $shippingPoints = getByPageShippingPoints($curPageNo);

    $lefMostPageInPagination = getFarthestPageNo($maxPages, $curPageNo)['leftMost'];
    $rightMostPageInPagination = getFarthestPageNo($maxPages, $curPageNo)['rightMost'];
  ?>

  <?php echo sideBarHTML(); ?>
  <?php echo navHTML(); ?>

  <main class="p-4 main shipping-points-main">
    <div class="mb-4 d-flex align-items-center justify-content-between create-shipping-point-modal-openup-container">
      <h1 class="mb-0 text-dark page-title shipping-points-title">Shipping Points</h1>
      <button class="btn btn-primary shadow-none create-shipping-point-modal-openup-btn" data-toggle="modal" data-target="#create-shipping-point-modal">Add a Shipping Point</button>
    </div>
    
    <!-- Table -->
    <table class="bg-white table table-bordered">
      <thead>
        <tr class="border-bottom-0">
          <th class="border-bottom-0 id">ID</th>
          <th class="border-bottom-0 name">Name</th>
          <th class="border-bottom-0 created-at">Created At</th>
          <th class="border-bottom-0 actions">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php 
          if(!$shippingPoints) {
            echo 
            "<tr>
              <td class='text-center' colspan='4'>No shipping points found</td>
            </tr>";
          } else {
            foreach ($shippingPoints as $shippingPoint) {
              extract($shippingPoint);

              $createdAt = date('F j, Y', strtotime($createdAt));

              echo 
              "<tr>
                <td class='border-bottom-0 id'>$id</td>
                <td class='border-bottom-0 name'>$name</td>
                <td class='border-bottom-0 created-at'>$createdAt</td>
                <td class='border-bottom-0 actions'>
                  <button class='btn btn-sm btn-info shadow-none'>
                    <i class='fas fa-edit'></i>
                  </button>
                  <button class='btn btn-sm btn-danger shadow-none' onclick='deleteShippingPointPre(event)' data-toggle='modal' data-target='#delete-shipping-point-modal' data-shipping-point-id='$id'>
                    <i class='fas fa-trash'></i>
                  </button>
                </td>
              </tr>";
            }
          }
        ?>
      </tbody>
    </table>
    <!-- Pagination -->
    <ul class="mt-4 pagination justify-content-center">
      <?php
        if($shippingPoints) {
          if($curPageNo - 1 > 0) {
            $pageNo = $curPageNo - 1;
            echo "<li class='page-item'><a class='page-link' href='./shipping-points.php?p=$pageNo'>Previous</a></li>";
          }
  
          for($pageNo = $lefMostPageInPagination; $pageNo <= $rightMostPageInPagination; $pageNo++) {
            $activeClass = ($pageNo == $curPageNo) ? 'active': '';
            echo "<li class='page-item $activeClass'><a class='page-link' href='./shipping-points.php?p=$pageNo'>$pageNo</a></li>";
          }
  
          if($curPageNo + 1 <= $maxPages) {
            $pageNo = $curPageNo + 1;
            echo "<li class='page-item'><a class='page-link' href='./shipping-points.php?p=$pageNo'>Next</a></li>";
          }
        }
      ?>
    </ul>

    <!-- Create Shipping Point Modal -->
    <div class="modal fade" id="create-shipping-point-modal" tabindex="-1">
      <div class="modal-dialog" role="document">
        <div class="p-4 modal-content">
          <span class="position-absolute modal-cross" data-dismiss="modal">
            <i class="fas fa-times"></i>
          </span>
          <h3 class="my-4 text-primary text-center modal-heading">Add a Shipping Point</h3>
          <form onsubmit="createShippingPoint(event)" class="create-shipping-point-form" id="create-shipping-point-form">
            <div class="form-group">
              <label for="create-shipping-point-name">Name</label>
              <input required minlength="1" maxlength="30" type="text" class="shadow-none form-control create-shipping-point-name" id="create-shipping-point-name">
            </div>
            <div class="form-group">
              <label for="create-shipping-point-location">Location</label>
              <input required minlength="1" maxlength="40" type="text" class="shadow-none form-control create-shipping-point-location" id="create-shipping-point-location">
            </div>
            <div class="form-group">
              <label for="create-shipping-point-desc">Description</label>
              <textarea required minlength="1" maxlength="500" type="text" class="shadow-none form-control create-shipping-point-desc" id="create-shipping-point-desc"></textarea>
            </div>
            <button class="mt-3 btn btn-primary shadow-none create-shipping-point-btn" id="create-shipping-point-btn">Add</button>
            <div class="d-none mt-4 text-center res-msg-container">
              <!-- response goes here -->
            </div>
          </form>
        </div>
      </div>
    </div>

    <!-- Delete Shipping Point Modal -->
    <div class="modal fade" id="delete-shipping-point-modal" tabindex="-1">
      <div class="modal-dialog" role="document">
        <div class="p-4 modal-content">
          <span class="position-absolute modal-cross" data-dismiss="modal">
            <i class="fas fa-times"></i>
          </span>
          <h3 class="my-4 text-danger text-center modal-heading">You sure deleting this shipping point?</h3>
          <form onsubmit="deleteShippingPoint(event)" class="delete-shipping-point-form" id="delete-shipping-point-form" data-shipping-point-id="">
            <div class="text-center delete-shipping-point-btn-container">
              <button class="btn btn-danger shadow-none delete-shipping-point-btn" id="delete-shipping-point-btn">Delete</button>
            </div>
            <div class="d-none mt-4 text-center res-msg-container">
              <!-- response goes here -->
            </div>
          </form>
        </div>
      </div>
    </div>
  </main>

  <!-- Shared -->
  <script src="../assets/js/shared/font-awesome.min.js"></script>
  <script src="../assets/js/shared/jquery.min.js"></script>
  <script src="../assets/js/shared/bootstrap.bundle.min.js"></script>
  <script src="../assets/js/shared/main.js"></script>
  <!-- Admin -->
  <script src="../assets/js/admin/shipping-points.js"></script>
  <script src="../assets/js/admin/logout.js"></script>
</body>
</html>